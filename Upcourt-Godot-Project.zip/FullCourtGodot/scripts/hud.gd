extends CanvasLayer

signal play_requested(config: Dictionary)
signal resume_requested
signal pause_requested
signal rematch_requested
signal menu_requested
signal substitution_requested(slot: int)
signal roster_saved

const RosterStore = preload("res://scripts/roster_store.gd")
const ORANGE := Color("ff8954")
const MUTED := Color("a9b3c0")
const INK := Color("f4f6fa")
const PANEL := Color("151e2a")
const LINE := Color("344153")

class ShotMeter extends Control:
	var amount: float = 0.0
	var target: float = 0.74
	var window: float = 0.12
	func _draw() -> void:
		var rect := Rect2(Vector2.ZERO, size)
		draw_style_box(_box(Color("111a26"), Color("566174")), rect)
		var lane := Rect2(10, 10, size.x - 20, size.y - 20)
		draw_rect(lane, Color("465267"))
		draw_rect(Rect2(lane.position, Vector2(lane.size.x * clampf(amount, 0, 1), lane.size.y)), Color("ffbd7e"))
		var start := clampf(target - window * 0.5, 0, 1)
		draw_rect(Rect2(lane.position + Vector2(lane.size.x * start, 0), Vector2(lane.size.x * window, lane.size.y)), Color("4de49c"))
		var cursor := lane.position.x + lane.size.x * clampf(amount, 0, 1)
		draw_line(Vector2(cursor, 5), Vector2(cursor, size.y - 5), Color.WHITE, 3)
	static func _box(fill: Color, border: Color) -> StyleBoxFlat:
		var style := StyleBoxFlat.new()
		style.bg_color = fill
		style.border_color = border
		style.set_border_width_all(1)
		style.set_corner_radius_all(7)
		return style

var root: Control
var menu_layer: Control
var game_layer: Control
var overlay_layer: Control
var feedback_box: PanelContainer
var feedback_title: Label
var feedback_detail: Label
var feedback_remaining: float = 0.0
var home_label: Label
var away_label: Label
var score_label: Label
var clock_label: Label
var possession_label: Label
var active_label: Label
var stats_label: Label
var clear_label: Label
var meter: ShotMeter
var meter_label: Label
var bench_box: VBoxContainer
var _bench_signature: String = ""
var _rosters: Array = []
var _page: String = "menu"
var _return_page: String = "menu"
var _last_config := {"home_index": 0, "away_index": 1, "mode": "half", "difficulty": 1, "quarter_seconds": 60}
var _home_select: OptionButton
var _away_select: OptionButton
var _mode_select: OptionButton
var _difficulty_select: OptionButton
var _quarter_select: OptionButton
var _roster_team: OptionButton
var _roster_player: OptionButton
var _name_edit: LineEdit
var _number_edit: SpinBox
var _height_edit: SpinBox
var _rating_inputs: Dictionary = {}
var _save_message: Label
var _editing_new: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10
	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = _theme()
	add_child(root)
	menu_layer = _layer()
	game_layer = _layer()
	overlay_layer = _layer()
	_build_game_hud()
	game_layer.hide()
	overlay_layer.hide()

func _process(delta: float) -> void:
	if feedback_remaining > 0:
		feedback_remaining = maxf(0, feedback_remaining - delta)
		feedback_box.visible = feedback_remaining > 0 and game_layer.visible

func _layer() -> Control:
	var control := Control.new()
	control.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	control.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(control)
	return control

func _theme() -> Theme:
	var theme := Theme.new()
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Inter", "Helvetica Neue", "Arial"])
	theme.default_font = font
	theme.default_font_size = 17
	theme.set_color("font_color", "Label", INK)
	for kind: String in ["Button", "OptionButton"]:
		theme.set_stylebox("normal", kind, _style(Color("243142"), LINE, 8, 12))
		theme.set_stylebox("hover", kind, _style(Color("35485c"), Color("7895a9"), 8, 12))
		theme.set_stylebox("pressed", kind, _style(Color("182531"), ORANGE, 8, 12))
		theme.set_stylebox("focus", kind, _style(Color.TRANSPARENT, ORANGE, 8, 1, 2))
		theme.set_color("font_color", kind, INK)
		theme.set_color("font_hover_color", kind, Color.WHITE)
		theme.set_color("font_disabled_color", kind, Color("667181"))
		theme.set_constant("h_separation", kind, 12)
	theme.set_stylebox("normal", "LineEdit", _style(Color("0e1620"), LINE, 7, 10))
	theme.set_stylebox("focus", "LineEdit", _style(Color("0e1620"), ORANGE, 7, 10))
	theme.set_color("font_color", "LineEdit", INK)
	theme.set_stylebox("panel", "PopupMenu", _style(PANEL, LINE, 8, 10))
	theme.set_stylebox("panel", "PanelContainer", _style(PANEL, LINE, 12, 22))
	var fill_track := _style(ORANGE, ORANGE, 3, 0)
	fill_track.content_margin_top = 3
	fill_track.content_margin_bottom = 3
	var track := _style(Color("344153"), Color("344153"), 3, 0)
	track.content_margin_top = 3
	track.content_margin_bottom = 3
	theme.set_stylebox("grabber_area", "HSlider", fill_track)
	theme.set_stylebox("slider", "HSlider", track)
	return theme

func _style(fill: Color, border: Color, radius: int = 8, margin: int = 12, thickness: int = 1) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(thickness)
	style.set_corner_radius_all(radius)
	style.content_margin_left = margin
	style.content_margin_right = margin
	style.content_margin_top = margin
	style.content_margin_bottom = margin
	return style

func _label(text: String, font_size: int = 17, color: Color = INK) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	if font_size >= 26:
		var font := SystemFont.new()
		font.font_names = PackedStringArray(["Inter", "Helvetica Neue", "Arial"])
		font.font_weight = 750
		label.add_theme_font_override("font", font)
	label.add_theme_color_override("font_color", color)
	return label

func _button(text: String, callback: Callable, accent: bool = false) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size.y = 44
	button.pressed.connect(callback)
	if accent:
		button.add_theme_stylebox_override("normal", _style(ORANGE, ORANGE, 8, 12))
		button.add_theme_stylebox_override("hover", _style(Color("ffad7e"), Color("ffad7e"), 8, 12))
		button.add_theme_color_override("font_color", Color("171619"))
		button.add_theme_color_override("font_hover_color", Color("171619"))
		button.add_theme_color_override("font_focus_color", Color("171619"))
	return button

func _vbox(parent: Node, spacing: int = 10) -> VBoxContainer:
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", spacing)
	parent.add_child(box)
	return box

func _hbox(parent: Node, spacing: int = 12) -> HBoxContainer:
	var box := HBoxContainer.new()
	box.add_theme_constant_override("separation", spacing)
	parent.add_child(box)
	return box

func _empty(control: Control) -> void:
	for child: Node in control.get_children():
		control.remove_child(child)
		child.queue_free()

func _backdrop(parent: Control, alpha: float = 0.75) -> void:
	var shade := ColorRect.new()
	shade.color = Color(0.025, 0.045, 0.08, alpha)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	parent.add_child(shade)

func _centered_panel(parent: Control, width: float = 520, height: float = 0) -> VBoxContainer:
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_left = 24
	center.offset_right = -24
	center.offset_top = 20
	center.offset_bottom = -20
	parent.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(width, height)
	center.add_child(panel)
	return _vbox(panel, 14)

func show_menu(rosters: Array) -> void:
	if root == null:
		return
	_rosters = rosters.duplicate(true)
	_page = "menu"
	game_layer.hide()
	overlay_layer.hide()
	menu_layer.show()
	_empty(menu_layer)
	_backdrop(menu_layer, 0.35)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 48)
	margin.add_theme_constant_override("margin_right", 48)
	margin.add_theme_constant_override("margin_top", 34)
	margin.add_theme_constant_override("margin_bottom", 28)
	menu_layer.add_child(margin)
	var outer := _vbox(margin, 16)
	var heading := _hbox(outer)
	var brand := _label("UPCOURT", 48, INK)
	brand.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heading.add_child(brand)
	var tag := _label("PICKUP  /  EXHIBITION", 14, ORANGE)
	tag.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	heading.add_child(tag)
	var row := _hbox(outer, 24)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var panel := PanelContainer.new()
	panel.custom_minimum_size.x = 430
	panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	row.add_child(panel)
	var content := _vbox(panel, 10)
	content.add_child(_label("PLAY NOW", 31))
	content.add_child(_label("Pick your matchup. Find your rhythm.", 15, MUTED))
	_home_select = _team_select(content, "YOUR TEAM", int(_last_config.home_index))
	_away_select = _team_select(content, "OPPONENT", int(_last_config.away_index))
	var options := _hbox(content)
	_mode_select = _choice(options, "COURT", ["Half court · 3 on 3", "Full court · 5 on 5"])
	_mode_select.select(0 if str(_last_config.mode) == "half" else 1)
	_difficulty_select = _choice(options, "DIFFICULTY", ["Rookie", "Pro", "All-Star"])
	_difficulty_select.select(int(_last_config.difficulty))
	var quarter_row := _hbox(content)
	_quarter_select = _choice(quarter_row, "QUARTER LENGTH", ["1 minute", "2 minutes"])
	_quarter_select.select(0 if int(_last_config.quarter_seconds) == 60 else 1)
	var half_rules := _label("3v3 · First to 11 · 1s and 2s · Clear after turnovers", 12, MUTED)
	half_rules.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(half_rules)
	var start_button := _button("Play Now   →", _start_from_menu, true)
	content.add_child(start_button)
	var utilities := _hbox(content)
	var controls := _button("Controls", show_controls)
	controls.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	utilities.add_child(controls)
	var roster := _button("Rosters / Create player", _show_roster_editor)
	roster.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	utilities.add_child(roster)
	content.add_child(_label("Keyboard + controller   •   Local single player", 12, MUTED))
	_mode_select.item_selected.connect(func(index: int) -> void:
		_quarter_select.disabled = index == 0
		half_rules.text = "3v3 · First to 11 · 1s and 2s · Clear after turnovers" if index == 0 else "5v5 · Four quarters · 24-second shot clock · Substitutions"
	)
	_quarter_select.disabled = _mode_select.selected == 0
	var side := _vbox(row, 16)
	side.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	side.add_spacer(false)
	var statement := _label("MAKE\nYOUR\nSPACE.", 58, Color("f2f8f6"))
	side.add_child(statement)
	var instructions := _label("Read the defense.\nTime the release.\nOwn the next possession.", 21, Color("d1dce3"))
	side.add_child(instructions)
	call_deferred("_focus", start_button)

func _team_select(parent: Node, title: String, index: int) -> OptionButton:
	var box := _vbox(parent, 4)
	box.add_child(_label(title, 12, MUTED))
	var select := OptionButton.new()
	select.custom_minimum_size.y = 39
	for team: Dictionary in _rosters:
		select.add_item(str(team.get("city", "")) + " " + str(team.get("name", "")))
	select.select(clampi(index, 0, maxi(0, _rosters.size() - 1)))
	box.add_child(select)
	return select

func _choice(parent: Node, title: String, options: Array) -> OptionButton:
	var box := _vbox(parent, 4)
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_child(_label(title, 12, MUTED))
	var select := OptionButton.new()
	select.custom_minimum_size.y = 38
	for option: String in options:
		select.add_item(option)
	box.add_child(select)
	return select

func _start_from_menu() -> void:
	if _rosters.size() < 2:
		return
	var home_index := _home_select.selected
	var away_index := _away_select.selected
	if home_index == away_index:
		away_index = (away_index + 1) % _rosters.size()
		_away_select.select(away_index)
	_last_config = {
		"home_index": home_index, "away_index": away_index,
		"mode": "half" if _mode_select.selected == 0 else "full",
		"difficulty": _difficulty_select.selected,
		"quarter_seconds": 60 if _quarter_select.selected == 0 else 120
	}
	play_requested.emit(_last_config.duplicate())

func _build_game_hud() -> void:
	var score_panel := PanelContainer.new()
	score_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	score_panel.offset_left = -330
	score_panel.offset_right = 330
	score_panel.offset_top = 18
	score_panel.offset_bottom = 99
	score_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	score_panel.add_theme_stylebox_override("panel", _style(Color(0.05, 0.08, 0.12, 0.95), LINE, 10, 12))
	game_layer.add_child(score_panel)
	var row := _hbox(score_panel, 22)
	home_label = _label("HBR", 23, Color("59d5d2"))
	home_label.custom_minimum_size.x = 155
	home_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(home_label)
	var middle := _vbox(row, 0)
	middle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	score_label = _label("0  –  0", 33)
	score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	middle.add_child(score_label)
	clock_label = _label("FIRST TO 11", 12, MUTED)
	clock_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	middle.add_child(clock_label)
	away_label = _label("CYN", 23, Color("f49b66"))
	away_label.custom_minimum_size.x = 155
	away_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	away_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	row.add_child(away_label)
	var top_right := HBoxContainer.new()
	top_right.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	top_right.offset_left = -120
	top_right.offset_right = -20
	top_right.offset_top = 20
	game_layer.add_child(top_right)
	top_right.add_child(_button("Pause", _request_pause))
	var lower := PanelContainer.new()
	lower.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	lower.offset_left = 20
	lower.offset_right = -20
	lower.offset_top = -85
	lower.offset_bottom = -16
	lower.add_theme_stylebox_override("panel", _style(Color(0.05, 0.08, 0.12, 0.88), LINE, 9, 12))
	lower.mouse_filter = Control.MOUSE_FILTER_IGNORE
	game_layer.add_child(lower)
	var footer := _hbox(lower, 22)
	var selected := _vbox(footer, 3)
	selected.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	active_label = _label("YOUR PLAYER", 17)
	selected.add_child(active_label)
	stats_label = _label("", 12, MUTED)
	selected.add_child(stats_label)
	var possession_box := _vbox(footer, 3)
	possession_label = _label("Your possession", 15, INK)
	possession_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	possession_box.add_child(possession_label)
	clear_label = _label("", 12, ORANGE)
	clear_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	possession_box.add_child(clear_label)
	feedback_box = PanelContainer.new()
	feedback_box.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	feedback_box.offset_left = -230
	feedback_box.offset_right = 230
	feedback_box.offset_top = 114
	feedback_box.offset_bottom = 170
	feedback_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	feedback_box.add_theme_stylebox_override("panel", _style(Color(0.04, 0.065, 0.1, 0.9), Color("49576c"), 8, 10))
	game_layer.add_child(feedback_box)
	var feedback_content := _vbox(feedback_box, 2)
	feedback_title = _label("", 20)
	feedback_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	feedback_content.add_child(feedback_title)
	feedback_detail = _label("", 13, MUTED)
	feedback_detail.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	feedback_content.add_child(feedback_detail)
	feedback_box.hide()
	meter = ShotMeter.new()
	meter.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	meter.offset_left = -150
	meter.offset_right = 150
	meter.offset_top = -146
	meter.offset_bottom = -114
	meter.mouse_filter = Control.MOUSE_FILTER_IGNORE
	game_layer.add_child(meter)
	meter.hide()
	meter_label = _label("RELEASE IN THE GREEN", 12, INK)
	meter_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	meter_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	meter_label.offset_left = -180
	meter_label.offset_right = 180
	meter_label.offset_top = -170
	meter_label.offset_bottom = -148
	game_layer.add_child(meter_label)
	meter_label.hide()
	bench_box = VBoxContainer.new()
	bench_box.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	bench_box.offset_left = -250
	bench_box.offset_right = -20
	bench_box.offset_top = 84
	bench_box.add_theme_constant_override("separation", 5)
	game_layer.add_child(bench_box)
	bench_box.hide()

# The game's pause action remains the single entry point for mouse and keyboard.
func _request_pause() -> void:
	pause_requested.emit()

func show_game() -> void:
	_page = "game"
	menu_layer.hide()
	overlay_layer.hide()
	game_layer.show()
	get_viewport().gui_release_focus()

func update_game(data: Dictionary) -> void:
	if game_layer == null:
		return
	var home: Dictionary = data.get("home", {})
	var away: Dictionary = data.get("away", {})
	home_label.text = str(home.get("abbr", "HOME"))
	away_label.text = str(away.get("abbr", "AWAY"))
	home_label.add_theme_color_override("font_color", Color(str(home.get("color", "#59d5d2"))))
	away_label.add_theme_color_override("font_color", Color(str(away.get("color", "#f49b66"))))
	var scores: Array = data.get("scores", [0, 0])
	score_label.text = "%d  –  %d" % [int(scores[0]), int(scores[1])]
	var mode := str(data.get("mode", "half"))
	clock_label.text = "FIRST TO 11  •  1s + 2s" if mode == "half" else "%s   %s   SHOT %s" % [str(data.get("quarter", "Q1")), str(data.get("clock", "1:00")), str(data.get("shot_clock", "24"))]
	possession_label.text = str(data.get("possession", ""))
	active_label.text = str(data.get("player", ""))
	stats_label.text = str(data.get("stats", ""))
	clear_label.text = "CLEAR THE BALL BEYOND THE ARC" if bool(data.get("clear_required", false)) else str(data.get("phase", ""))
	var bench: Array = data.get("bench", [])
	var can_substitute := bool(data.get("can_substitute", false)) and mode == "full"
	bench_box.visible = can_substitute
	var signature := JSON.stringify(bench)
	if can_substitute and signature != _bench_signature:
		_bench_signature = signature
		_empty(bench_box)
		bench_box.add_child(_label("SUBSTITUTE FOR SELECTED PLAYER", 11, MUTED))
		for i: int in range(bench.size()):
			var player: Dictionary = bench[i] if bench[i] is Dictionary else {"name": str(bench[i])}
			var slot := int(player.get("slot", i))
			var button := _button("%s  ·  %s" % [str(int(player.get("number", 0))), str(player.get("name", "Player"))], func() -> void: substitution_requested.emit(slot))
			button.add_theme_font_size_override("font_size", 13)
			bench_box.add_child(button)

func show_pause() -> void:
	_page = "pause"
	_open_modal()
	var box := _centered_panel(overlay_layer, 440)
	box.add_child(_label("TIME OUT", 12, ORANGE))
	box.add_child(_label("Game paused", 32))
	var resume_button := _button("Resume", func() -> void: resume_requested.emit(), true)
	box.add_child(resume_button)
	box.add_child(_button("Controls", show_controls))
	box.add_child(_button("Rematch", func() -> void: rematch_requested.emit()))
	box.add_child(_button("Back to Play Now", func() -> void: menu_requested.emit()))
	call_deferred("_focus", resume_button)

func _open_modal() -> void:
	_empty(overlay_layer)
	overlay_layer.show()
	_backdrop(overlay_layer, 0.7)

func show_result(title: String, detail: String) -> void:
	_page = "result"
	_open_modal()
	var box := _centered_panel(overlay_layer, 490)
	box.add_child(_label("FINAL", 12, ORANGE))
	box.add_child(_label(title, 34))
	var detail_label := _label(detail, 18, MUTED)
	detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(detail_label)
	var rematch := _button("Run it back", func() -> void: rematch_requested.emit(), true)
	box.add_child(rematch)
	box.add_child(_button("Back to Play Now", func() -> void: menu_requested.emit()))
	call_deferred("_focus", rematch)

func show_break(title: String, detail: String) -> void:
	_page = "break"
	_open_modal()
	var box := _centered_panel(overlay_layer, 490)
	box.add_child(_label("EXHIBITION", 12, ORANGE))
	box.add_child(_label(title, 32))
	box.add_child(_label(detail, 18, MUTED))
	var continue_button := _button("Continue", func() -> void: resume_requested.emit(), true)
	box.add_child(continue_button)
	box.add_child(_button("Back to Play Now", func() -> void: menu_requested.emit()))
	call_deferred("_focus", continue_button)

func show_controls() -> void:
	_return_page = _page
	_page = "controls"
	_open_modal()
	var box := _centered_panel(overlay_layer, 670)
	box.add_child(_label("CONTROLS", 32))
	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 30)
	grid.add_theme_constant_override("v_separation", 13)
	box.add_child(grid)
	for heading: String in ["ACTION", "KEYBOARD", "CONTROLLER"]:
		grid.add_child(_label(heading, 12, ORANGE))
	var controls := [
		["Move", "W A S D / arrows", "Left stick"],
		["Sprint", "Hold Shift", "Hold RT"],
		["Jump shot / layup", "Hold + release Space", "Hold + release X"],
		["Pass / steal", "E", "A"],
		["Switch player", "Q", "LB"],
		["Block / rebound", "R", "Y"],
		["Crossover", "F", "B"],
		["Pause", "Escape", "Start"]
	]
	for row: Array in controls:
		for item: String in row:
			grid.add_child(_label(item, 16, INK))
	var hint := _label("Aim a pass with your movement direction. Release in the green window.\nCreate space before shooting. Clear beyond the arc after a defensive rebound or steal.", 14, MUTED)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(hint)
	var back := _button("Back", _close_controls, true)
	box.add_child(back)
	call_deferred("_focus", back)

func _close_controls() -> void:
	if _return_page == "menu":
		show_menu(_rosters)
	else:
		show_pause()

func show_feedback(text: String, detail: String = "", good: bool = false) -> void:
	feedback_title.text = text
	feedback_title.add_theme_color_override("font_color", Color("74f1b1") if good else INK)
	feedback_detail.text = detail
	feedback_detail.visible = not detail.is_empty()
	feedback_remaining = 2.2
	feedback_box.show()

func set_meter(value: float, center: float, width: float, visible: bool) -> void:
	meter.amount = value
	meter.target = center
	meter.window = width
	meter.visible = visible
	meter_label.visible = visible
	meter.queue_redraw()

func _show_roster_editor() -> void:
	_page = "roster"
	_open_modal()
	var box := _centered_panel(overlay_layer, 730)
	box.add_child(_label("LOCAL ROSTERS", 12, ORANGE))
	box.add_child(_label("Edit your players", 29))
	var selectors := _hbox(box)
	_roster_team = _team_select(selectors, "TEAM", 0)
	_roster_team.get_parent().size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var player_box := _vbox(selectors, 4)
	player_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	player_box.add_child(_label("PLAYER", 12, MUTED))
	_roster_player = OptionButton.new()
	_roster_player.custom_minimum_size.y = 39
	player_box.add_child(_roster_player)
	var identity := _hbox(box)
	var name_box := _vbox(identity, 3)
	name_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_box.add_child(_label("NAME", 12, MUTED))
	_name_edit = LineEdit.new()
	_name_edit.max_length = 40
	_name_edit.custom_minimum_size.y = 38
	name_box.add_child(_name_edit)
	var number_box := _vbox(identity, 3)
	number_box.add_child(_label("JERSEY", 12, MUTED))
	_number_edit = SpinBox.new()
	_number_edit.min_value = 0
	_number_edit.max_value = 99
	number_box.add_child(_number_edit)
	var height_box := _vbox(identity, 3)
	height_box.add_child(_label("HEIGHT (M)", 12, MUTED))
	_height_edit = SpinBox.new()
	_height_edit.min_value = 1.5
	_height_edit.max_value = 2.5
	_height_edit.step = 0.01
	height_box.add_child(_height_edit)
	var rating_grid := GridContainer.new()
	rating_grid.columns = 3
	rating_grid.add_theme_constant_override("h_separation", 14)
	rating_grid.add_theme_constant_override("v_separation", 10)
	box.add_child(rating_grid)
	_rating_inputs.clear()
	for key: String in RosterStore.RATING_KEYS:
		rating_grid.add_child(_label(key.capitalize(), 15, INK))
		var slider := HSlider.new()
		slider.min_value = 25
		slider.max_value = 99
		slider.step = 1
		slider.custom_minimum_size = Vector2(330, 24)
		slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		rating_grid.add_child(slider)
		var value := _label("75", 15, ORANGE)
		value.custom_minimum_size.x = 30
		rating_grid.add_child(value)
		slider.value_changed.connect(func(amount: float) -> void: value.text = str(int(amount)))
		_rating_inputs[key] = slider
	_save_message = _label("Changes are saved locally on this Mac.", 13, MUTED)
	box.add_child(_save_message)
	var actions := _hbox(box)
	var save := _button("Save player", _save_player, true)
	save.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions.add_child(save)
	actions.add_child(_button("Create player", _new_player))
	actions.add_child(_button("Back", func() -> void: show_menu(_rosters)))
	_roster_team.item_selected.connect(func(_index: int) -> void: _populate_players())
	_roster_player.item_selected.connect(func(_index: int) -> void: _load_player())
	_populate_players()

func _populate_players() -> void:
	_roster_player.clear()
	var team: Dictionary = _rosters[_roster_team.selected]
	for player: Dictionary in team["players"]:
		_roster_player.add_item("#%s  %s" % [str(int(player["number"])), str(player["name"])])
	_roster_player.select(0)
	_load_player()

func _load_player() -> void:
	_editing_new = false
	var team: Dictionary = _rosters[_roster_team.selected]
	var player: Dictionary = team["players"][_roster_player.selected]
	_name_edit.text = str(player["name"])
	_number_edit.value = float(player["number"])
	_height_edit.value = float(player["height"])
	for key: String in RosterStore.RATING_KEYS:
		_rating_inputs[key].value = float(player["ratings"][key])
	_save_message.text = "Changes are saved locally on this Mac."

func _new_player() -> void:
	_editing_new = true
	_name_edit.text = "New Player"
	_number_edit.value = 0
	_height_edit.value = 1.96
	for key: String in RosterStore.RATING_KEYS:
		_rating_inputs[key].value = 75
	_save_message.text = "Save to add this player to the selected team's bench."
	_name_edit.grab_focus()
	_name_edit.select_all()

func _save_player() -> void:
	if _name_edit.text.strip_edges().is_empty():
		_save_message.text = "Enter a player name."
		return
	var next_rosters := _rosters.duplicate(true)
	var team: Dictionary = next_rosters[_roster_team.selected]
	var players: Array = team["players"]
	var selected := _roster_player.selected
	var player: Dictionary
	if _editing_new:
		player = {"id": str(team["id"]) + "-custom-" + str(Time.get_unix_time_from_system()).replace(".", "-"), "model_path": ""}
		players.append(player)
		selected = players.size() - 1
	else:
		player = players[selected]
	player["name"] = _name_edit.text.strip_edges()
	player["number"] = int(_number_edit.value)
	player["height"] = _height_edit.value
	player["ratings"] = {}
	for key: String in RosterStore.RATING_KEYS:
		player["ratings"][key] = int(_rating_inputs[key].value)
	var validation := RosterStore.validate_teams(next_rosters)
	if not validation.is_empty():
		_save_message.text = validation
		return
	var error := RosterStore.save_teams(next_rosters)
	if error != OK:
		_save_message.text = "Could not save the roster. Error " + str(error)
		return
	_rosters = next_rosters
	_populate_players()
	_roster_player.select(selected)
	_load_player()
	_save_message.text = "Saved locally. The next match uses these ratings."
	roster_saved.emit()

func _focus(control: Control) -> void:
	if is_instance_valid(control) and control.is_inside_tree() and control.is_visible_in_tree():
		control.grab_focus()
