extends Node3D

var _left_leg: Node3D
var _right_leg: Node3D
var _left_arm: Node3D
var _right_arm: Node3D
var _left_forearm: Node3D
var _right_forearm: Node3D
var _torso: Node3D
var _marker: MeshInstance3D
var _name_label: Label3D
var _animation_time: float = 0.0
var _selected: bool = false
var _body: Node3D
var _head: Node3D
var _knees: Array[Node3D] = []
var _ankles: Array[Node3D] = []
var _wrists: Array[Node3D] = []
var _context: Dictionary = {}
var _height_scale: float = 1.0

func set_motion_context(context: Dictionary) -> void:
	_context = context


func build(player_data: Dictionary, team_color: Color, trim_color: Color) -> void:
	for child in get_children():
		remove_child(child)
		child.queue_free()
	_knees.clear()
	_ankles.clear()
	_wrists.clear()
	_body = Node3D.new()
	add_child(_body)
	_height_scale = float(player_data.get("height", 1.9)) / 1.9
	_body.scale = Vector3(1.0,_height_scale,1.0)
	var skin_palette: Array[String] = ["734831","a86d49","c98f68","613c2c","b97e58","8c593f"]
	var variant: int = absi(str(player_data.get("id", "player")).hash())
	var skin_color: Color = Color(str(player_data.get("skin", skin_palette[variant % skin_palette.size()])))
	var skin := _material(skin_color)
	var jersey := _material(team_color)
	var trim := _material(trim_color)
	var shorts := _material(team_color.darkened(0.14))
	var shoes := _material(Color("e4e9e8"))
	var hair := _material(Color("1c2026"))
	_torso = Node3D.new()
	_torso.name = "Torso"
	_body.add_child(_torso)
	_shaped_jersey(_torso, jersey)
	for side: float in [-1.0, 1.0]:
		_box(_torso, Vector3(0.024, 0.44, 0.28), Vector3(side * 0.22, 1.23, 0), trim)
	_box(_torso, Vector3(0.43, 0.07, 0.3), Vector3(0, 0.99, 0), trim)
	_capsule(_torso, Vector3(0, 1.54, 0), 0.075, 0.14, skin)
	_head = Node3D.new()
	_head.position = Vector3(0,1.62,0)
	_torso.add_child(_head)
	_sphere(_head, Vector3(0,0.12,0), Vector3(0.27,0.34,0.27), skin)
	_sphere(_head, Vector3(0,0.02,-0.035), Vector3(0.21,0.18,0.23), skin)
	_sphere(_head, Vector3(0,0.11,-0.145), Vector3(0.048,0.066,0.056), skin)
	for side: float in [-1.0,1.0]:
		_sphere(_head, Vector3(side*0.138,0.12,0), Vector3(0.045,0.085,0.055), skin)
		_sphere(_head, Vector3(side*0.057,0.16,-0.125), Vector3(0.044,0.023,0.018), shoes)
		_sphere(_head, Vector3(side*0.057,0.16,-0.136), Vector3(0.018,0.020,0.009), hair)
		_box(_head,Vector3(0.052,0.013,0.018),Vector3(side*0.057,0.19,-0.12),hair)
	_box(_head,Vector3(0.063,0.012,0.015),Vector3(0,0.046,-0.134),_material(skin_color.darkened(0.38)))
	_sphere(_head, Vector3(0,0.25,0.012), Vector3(0.28,0.15 if variant%2==0 else 0.21,0.28), hair)
	if variant%3==0:
		for tuft in range(7):
			_sphere(_head,Vector3(sin(tuft*2.4)*0.085,0.30,cos(tuft*2.4)*0.085),Vector3(0.09,0.11,0.09),hair)
	if variant%2==0:
		_box(_head,Vector3(0.27,0.037,0.025),Vector3(0,0.22,-0.118),trim)
	# Collar and fabric seams give the jersey a visible layered edge.
	for side: float in [-1.0,1.0]:
		var collar := _add_mesh(_torso,BoxMesh.new(),Vector3(side*0.065,1.48,-0.135),trim)
		collar.mesh.size = Vector3(0.14,0.028,0.025)
		collar.rotation.z = side*0.35
	for seam in range(3):
		_box(_torso,Vector3(0.13,0.009,0.006),Vector3(-0.08+seam*0.07,1.04+seam*0.045,-0.16),_material(team_color.darkened(0.12)))
	var number := Label3D.new()
	number.text = str(int(player_data.get("number", 7)))
	number.font_size = 64
	number.pixel_size = 0.0036
	number.outline_size = 0
	number.modulate = trim_color
	number.position = Vector3(0, 1.27, -0.177)
	number.rotation.y = PI
	_torso.add_child(number)
	var back_number := Label3D.new()
	back_number.text = number.text
	back_number.font_size = 64
	back_number.pixel_size = 0.0036
	back_number.outline_size = 0
	back_number.modulate = trim_color
	back_number.position = Vector3(0, 1.28, 0.205)
	_torso.add_child(back_number)
	_left_leg = _make_leg(-1.0, skin, shorts, trim, shoes)
	_right_leg = _make_leg(1.0, skin, shorts, trim, shoes)
	_left_arm = _make_arm(-1.0, skin, trim)
	_right_arm = _make_arm(1.0, skin, trim)
	_left_forearm = _left_arm.get_node("Forearm")
	_right_forearm = _right_arm.get_node("Forearm")
	var ring := TorusMesh.new()
	ring.inner_radius = 0.4
	ring.outer_radius = 0.46
	ring.rings = 32
	ring.ring_segments = 6
	_marker = MeshInstance3D.new()
	_marker.name = "SelectedPlayerRing"
	_marker.mesh = ring
	var marker_material := _material(Color("ffe9a6"))
	marker_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_marker.material_override = marker_material
	_marker.position.y = 0.035
	add_child(_marker)
	_name_label = Label3D.new()
	_name_label.text = str(player_data.get("name", "PLAYER"))
	_name_label.font_size = 32
	_name_label.pixel_size = 0.007
	_name_label.outline_size = 7
	_name_label.outline_modulate = Color("131d28")
	_name_label.modulate = Color("fff3cd")
	_name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_name_label.position = Vector3(0, 2.14*_height_scale, 0)
	add_child(_name_label)
	set_selected(false)

func set_selected(selected: bool) -> void:
	_selected = selected
	if is_instance_valid(_marker):
		_marker.visible = selected
	if is_instance_valid(_name_label):
		_name_label.visible = selected

func animate(speed: float, has_ball: bool, shoot_amount: float, jump: float, delta: float) -> void:
	if not is_instance_valid(_torso):
		return
	_animation_time += delta * (3.0 + speed * 1.6)
	position.y = jump
	var run: float = clampf(speed/6.0,0,1)
	var stride: float = sin(_animation_time)*0.68*run
	var defense: float = 1.0 if bool(_context.get("defending",false)) else 0.0
	var crouch: float = 0.10*defense + 0.04*float(has_ball)
	_body.position.y = -crouch + absf(sin(_animation_time))*0.025*run
	_left_leg.rotation.x = stride-0.12*defense
	_right_leg.rotation.x = -stride-0.12*defense
	for i in range(2):
		var cycle: float = _animation_time + i*PI
		_knees[i].rotation.x = -maxf(0.0,sin(cycle))*0.95*run-0.22*defense
		_ankles[i].rotation.x = maxf(0.0,sin(cycle))*0.32*run
		if jump>0.05:
			_knees[i].rotation.x -= minf(jump,0.7)*0.6
	_torso.rotation.x = -0.10*run-0.05*defense
	_torso.rotation.y = sin(_animation_time)*0.09*run
	_head.rotation.y = -_torso.rotation.y*0.7
	_head.rotation.x = 0.02*sin(_animation_time*0.3)
	var shot: float = maxf(shoot_amount,float(_context.get("follow_through",0.0)))
	var targets: Array[float] = [-stride*0.72,stride*0.72]
	var hand_side: float = float(_context.get("hand",1.0))
	for i in range(2):
		var arm: Node3D = _left_arm if i==0 else _right_arm
		var elbow: Node3D = _left_forearm if i==0 else _right_forearm
		var side: float = -1.0 if i==0 else 1.0
		var elbow_angle: float = 0.38 + run*0.42
		var wrist_angle: float = 0.1
		var arm_spread: float = side*(0.12+defense*0.55)
		if has_ball and shot<0.1 and side==hand_side:
			var bounce: float = float(_context.get("bounce",0.5))
			targets[i] = 0.2+0.3*bounce
			elbow_angle = 0.15+0.65*bounce
			wrist_angle = -0.2-0.4*(1.0-bounce)
		if float(_context.get("move_progress",-1.0))>=0.0 and has_ball:
			var sweep: float = sin(float(_context.move_progress)*PI)
			arm_spread = side*(0.15-0.55*sweep)
			targets[i] = 0.45 if str(_context.get("move_kind","cross"))!="behind" else -0.45
			elbow_angle = 0.6
		if shot>0.05:
			targets[i] = lerpf(1.1,2.85,clampf(shot,0,1))
			elbow_angle = lerpf(1.05,0.12,clampf(shot,0,1))
			wrist_angle = -0.65 if shot>0.75 else 0.15
			arm_spread = side*0.1
		if float(_context.get("pass_pose",0))>0.0:
			targets[i] = 1.45
			elbow_angle = 0.15
		arm.rotation.x = lerp_angle(arm.rotation.x,targets[i],minf(delta*18,1))
		arm.rotation.z = lerpf(arm.rotation.z,arm_spread,minf(delta*18,1))
		elbow.rotation.x = -elbow_angle
		_wrists[i].rotation.x = wrist_angle
	_marker.position.y = 0.035-jump

func _make_leg(side: float, skin: Material, shorts: Material, trim: Material, shoes: Material) -> Node3D:
	var hip := Node3D.new()
	hip.position = Vector3(side*0.14,0.96,0)
	_body.add_child(hip)
	_capsule(hip,Vector3(0,-0.15,0),0.12,0.34,shorts)
	_box(hip,Vector3(0.21,0.035,0.23),Vector3(0,-0.29,0),trim)
	_capsule(hip,Vector3(0,-0.33,0),0.09,0.23,skin)
	var knee := Node3D.new()
	knee.position.y = -0.43
	hip.add_child(knee)
	_knees.append(knee)
	_sphere(knee,Vector3.ZERO,Vector3(0.17,0.17,0.17),skin)
	_capsule(knee,Vector3(0,-0.19,0.015),0.074,0.38,skin)
	_capsule(knee,Vector3(0,-0.34,0),0.065,0.17,shoes)
	var ankle := Node3D.new()
	ankle.position.y = -0.43
	knee.add_child(ankle)
	_ankles.append(ankle)
	_sphere(ankle,Vector3(0,-0.01,-0.07),Vector3(0.17,0.15,0.32),shoes)
	_box(ankle,Vector3(0.175,0.028,0.32),Vector3(0,-0.064,-0.07),trim)
	_box(ankle,Vector3(0.18,0.022,0.325),Vector3(0,-0.079,-0.07),_material(Color("272c34")))
	for lace in range(3):
		_box(ankle,Vector3(0.08,0.009,0.013),Vector3(0,0.052,-0.04-lace*0.04),trim)
	return hip

func _make_arm(side: float, skin: Material, trim: Material) -> Node3D:
	var shoulder := Node3D.new()
	shoulder.position = Vector3(side*0.265,1.44,0)
	_torso.add_child(shoulder)
	_sphere(shoulder,Vector3(0,-0.02,0),Vector3(0.18,0.21,0.20),skin)
	_capsule(shoulder,Vector3(0,-0.17,0),0.077,0.34,skin)
	var elbow := Node3D.new()
	elbow.name = "Forearm"
	elbow.position.y = -0.32
	shoulder.add_child(elbow)
	_sphere(elbow,Vector3.ZERO,Vector3(0.13,0.13,0.13),skin)
	_capsule(elbow,Vector3(0,-0.13,0),0.062,0.28,skin)
	_capsule(elbow,Vector3(0,-0.25,0),0.063,0.06,trim)
	var wrist := Node3D.new()
	wrist.position.y = -0.29
	elbow.add_child(wrist)
	_wrists.append(wrist)
	_sphere(wrist,Vector3(0,-0.04,0),Vector3(0.095,0.13,0.065),skin)
	for digit in range(4):
		_capsule(wrist,Vector3(-0.033+digit*0.022,-0.12,-0.01),0.011,0.085,skin)
	_sphere(wrist,Vector3(side*0.055,-0.04,-0.015),Vector3(0.04,0.07,0.04),skin)
	return shoulder

func _shaped_jersey(parent: Node3D, material: Material) -> void:
	var rings: Array = [[0.98,0.21,0.155],[1.08,0.205,0.15],[1.30,0.25,0.17],[1.44,0.25,0.155],[1.50,0.12,0.115]]
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for row in range(rings.size()-1):
		for segment in range(24):
			for corner in [[0,0],[1,0],[1,1],[0,0],[1,1],[0,1]]:
				var ring: Array = rings[row+corner[0]]
				var angle: float = float(segment+corner[1])*TAU/24.0
				surface.set_normal(Vector3(sin(angle),0,cos(angle)))
				surface.add_vertex(Vector3(sin(angle)*ring[1],ring[0],cos(angle)*ring[2]))
	var mesh := MeshInstance3D.new()
	mesh.mesh = surface.commit()
	mesh.material_override = material
	parent.add_child(mesh)

func _material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.82
	return material

func _box(parent: Node3D, size: Vector3, center: Vector3, material: Material) -> void:
	var mesh := BoxMesh.new()
	mesh.size = size
	_add_mesh(parent, mesh, center, material)

func _capsule(parent: Node3D, center: Vector3, radius: float, height: float, material: Material) -> void:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = maxf(height, radius * 2.0)
	mesh.radial_segments = 16
	mesh.rings = 5
	_add_mesh(parent, mesh, center, material)

func _sphere(parent: Node3D, center: Vector3, size: Vector3, material: Material) -> void:
	var mesh := SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mesh.radial_segments = 20
	mesh.rings = 10
	var instance := _add_mesh(parent, mesh, center, material)
	instance.scale = size

func _add_mesh(parent: Node3D, mesh: Mesh, center: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	instance.position = center
	parent.add_child(instance)
	return instance
