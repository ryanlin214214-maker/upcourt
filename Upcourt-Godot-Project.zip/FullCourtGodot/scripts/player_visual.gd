extends Node3D

var _left_leg: Node3D
var _right_leg: Node3D
var _left_arm: Node3D
var _right_arm: Node3D
var _left_forearm: Node3D
var _right_forearm: Node3D
var _torso: Node3D
var _marker: MeshInstance3D
var _name_label: Label3D
var _animation_time: float = 0.0
var _selected: bool = false

func build(player_data: Dictionary, team_color: Color, trim_color: Color) -> void:
	for child in get_children():
		remove_child(child)
		child.queue_free()
	var skin_color: Color = Color(str(player_data.get("skin", "ad7955")))
	var skin := _material(skin_color)
	var jersey := _material(team_color)
	var trim := _material(trim_color)
	var shorts := _material(team_color.darkened(0.14))
	var shoes := _material(Color("e4e9e8"))
	var hair := _material(Color("1c2026"))
	_torso = Node3D.new()
	_torso.name = "Torso"
	add_child(_torso)
	_capsule(_torso, Vector3(0, 1.23, 0), 0.23, 0.6, jersey)
	_box(_torso, Vector3(0.43, 0.36, 0.3), Vector3(0, 1.21, -0.018), jersey)
	for side: float in [-1.0, 1.0]:
		_box(_torso, Vector3(0.024, 0.44, 0.28), Vector3(side * 0.22, 1.23, 0), trim)
	_box(_torso, Vector3(0.43, 0.07, 0.3), Vector3(0, 0.99, 0), trim)
	_capsule(_torso, Vector3(0, 1.54, 0), 0.075, 0.14, skin)
	_sphere(_torso, Vector3(0, 1.72, -0.015), Vector3(0.27, 0.34, 0.28), skin)
	_sphere(_torso, Vector3(0, 1.83, 0.006), Vector3(0.276, 0.13, 0.27), hair)
	_sphere(_torso, Vector3(0, 1.72, -0.161), Vector3(0.058, 0.06, 0.045), skin)
	for side: float in [-1.0, 1.0]:
		_sphere(_torso, Vector3(side * 0.058, 1.76, -0.139), Vector3(0.018, 0.016, 0.012), hair)
	var number := Label3D.new()
	number.text = str(player_data.get("number", 7))
	number.font_size = 64
	number.pixel_size = 0.0036
	number.outline_size = 0
	number.modulate = trim_color
	number.position = Vector3(0, 1.27, -0.177)
	number.rotation.y = PI
	_torso.add_child(number)
	var back_number := Label3D.new()
	back_number.text = number.text
	back_number.font_size = 64
	back_number.pixel_size = 0.0036
	back_number.outline_size = 0
	back_number.modulate = trim_color
	back_number.position = Vector3(0, 1.28, 0.205)
	_torso.add_child(back_number)
	_left_leg = _make_leg(-1.0, skin, shorts, trim, shoes)
	_right_leg = _make_leg(1.0, skin, shorts, trim, shoes)
	_left_arm = _make_arm(-1.0, skin, trim)
	_right_arm = _make_arm(1.0, skin, trim)
	_left_forearm = _left_arm.get_node("Forearm")
	_right_forearm = _right_arm.get_node("Forearm")
	var ring := TorusMesh.new()
	ring.inner_radius = 0.4
	ring.outer_radius = 0.46
	ring.rings = 32
	ring.ring_segments = 6
	_marker = MeshInstance3D.new()
	_marker.name = "SelectedPlayerRing"
	_marker.mesh = ring
	var marker_material := _material(Color("ffe9a6"))
	marker_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_marker.material_override = marker_material
	_marker.position.y = 0.035
	add_child(_marker)
	_name_label = Label3D.new()
	_name_label.text = str(player_data.get("name", "PLAYER"))
	_name_label.font_size = 32
	_name_label.pixel_size = 0.007
	_name_label.outline_size = 7
	_name_label.outline_modulate = Color("131d28")
	_name_label.modulate = Color("fff3cd")
	_name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_name_label.position = Vector3(0, 2.14, 0)
	add_child(_name_label)
	set_selected(false)

func set_selected(selected: bool) -> void:
	_selected = selected
	if is_instance_valid(_marker):
		_marker.visible = selected
	if is_instance_valid(_name_label):
		_name_label.visible = selected

func animate(speed: float, has_ball: bool, shoot_amount: float, jump: float, delta: float) -> void:
	if not is_instance_valid(_torso):
		return
	_animation_time += delta * (3.0 + speed * 1.8)
	position.y = jump
	var running: float = clampf(speed / 5.0, 0.0, 1.0)
	var stride: float = sin(_animation_time) * 0.62 * running
	_left_leg.rotation.x = stride
	_right_leg.rotation.x = -stride
	_torso.position.y = absf(sin(_animation_time)) * 0.028 * running
	_torso.rotation.x = -0.07 * running
	var shot: float = clampf(shoot_amount, 0.0, 1.0)
	var left_target: float = lerpf(-stride * 0.7, 2.2, shot)
	var right_target: float = lerpf(stride * 0.7, 2.3, shot)
	if has_ball and shot < 0.1:
		right_target = 0.32 + sin(_animation_time * 1.35) * 0.25
	_left_arm.rotation.x = lerp_angle(_left_arm.rotation.x, left_target, minf(delta * 20.0, 1.0))
	_right_arm.rotation.x = lerp_angle(_right_arm.rotation.x, right_target, minf(delta * 20.0, 1.0))
	_left_forearm.rotation.x = lerpf(0.2, 0.68, shot)
	_right_forearm.rotation.x = lerpf(0.3 if has_ball else 0.2, 0.64, shot)
	_marker.position.y = 0.035 - jump

func _make_leg(side: float, skin: Material, shorts: Material, trim: Material, shoes: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = Vector3(side * 0.13, 0.9, 0)
	add_child(pivot)
	_capsule(pivot, Vector3(0, -0.17, 0), 0.108, 0.36, shorts)
	_box(pivot, Vector3(0.19, 0.045, 0.23), Vector3(0, -0.31, 0), trim)
	_capsule(pivot, Vector3(0, -0.47, 0), 0.072, 0.4, skin)
	_capsule(pivot, Vector3(0, -0.72, 0), 0.059, 0.23, skin)
	_box(pivot, Vector3(0.145, 0.11, 0.29), Vector3(0, -0.83, -0.045), shoes)
	return pivot

func _make_arm(side: float, skin: Material, trim: Material) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = Vector3(side * 0.27, 1.45, 0)
	pivot.rotation.z = side * 0.12
	_torso.add_child(pivot)
	_capsule(pivot, Vector3(0, -0.145, 0), 0.075, 0.34, skin)
	var forearm := Node3D.new()
	forearm.name = "Forearm"
	forearm.position.y = -0.29
	pivot.add_child(forearm)
	_capsule(forearm, Vector3(0, -0.14, 0), 0.06, 0.31, skin)
	_capsule(forearm, Vector3(0, -0.265, 0), 0.063, 0.06, trim)
	_sphere(forearm, Vector3(0, -0.33, 0), Vector3(0.11, 0.15, 0.09), skin)
	return pivot

func _material(color: Color) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.82
	return material

func _box(parent: Node3D, size: Vector3, center: Vector3, material: Material) -> void:
	var mesh := BoxMesh.new()
	mesh.size = size
	_add_mesh(parent, mesh, center, material)

func _capsule(parent: Node3D, center: Vector3, radius: float, height: float, material: Material) -> void:
	var mesh := CapsuleMesh.new()
	mesh.radius = radius
	mesh.height = maxf(height, radius * 2.0)
	mesh.radial_segments = 10
	mesh.rings = 3
	_add_mesh(parent, mesh, center, material)

func _sphere(parent: Node3D, center: Vector3, size: Vector3, material: Material) -> void:
	var mesh := SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mesh.radial_segments = 12
	mesh.rings = 6
	var instance := _add_mesh(parent, mesh, center, material)
	instance.scale = size

func _add_mesh(parent: Node3D, mesh: Mesh, center: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	instance.position = center
	parent.add_child(instance)
	return instance
