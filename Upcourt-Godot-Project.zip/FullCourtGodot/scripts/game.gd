extends Node3D
## Basketball simulation. All actors use Player.tick(), start_shot(), release_shot(),
## pass_ball(), try_steal(), and jump(): AI supplies decisions, never different physics.

const Athlete = preload("res://scripts/player.gd")
const RosterStore = preload("res://scripts/roster_store.gd")
const Sound = preload("res://scripts/sound.gd")
const ARC_RADIUS: float = 6.7
const GRAVITY: float = 9.81
const BALL_RADIUS: float = 0.12
const TARGET_SCORE: int = 11

var teams: Array = []
var selected_teams: Array = []
var players: Array = []
var ball_owner = null
var active = null
var passer = null
var receiver = null
var shooter = null
var possession_team: int = 0
var last_touch_team: int = 0
var needs_clear: bool = false
var ball_state: String = "held"
var ball_position: Vector3 = Vector3.ZERO
var ball_velocity: Vector3 = Vector3.ZERO
var ball_origin: Vector3 = Vector3.ZERO
var ball_target: Vector3 = Vector3.ZERO
var ball_elapsed: float = 0.0
var flight_duration: float = 1.0
var shot_points: int = 1
var shot_id: int = 0
var resolved_shot_id: int = -1
var planned_make: bool = false
var shot_report: Dictionary = {}
var scores: Array[int] = [0, 0]
var attempts: Array[int] = [0, 0]
var makes: Array[int] = [0, 0]
var steals: Array[int] = [0, 0]
var blocks: Array[int] = [0, 0]
var rebounds: Array[int] = [0, 0]
var phase: String = "menu"
var previous_phase: String = "live"
var config: Dictionary = {"home_index":0,"away_index":1,"mode":"half","difficulty":1,"quarter_seconds":60}
var full_court: bool = false
var court_limit: float = 7.0
var roster_size: int = 3
var quarter: int = 1
var game_clock: float = 60.0
var shot_clock: float = 20.0
var period_expired: bool = false
var elapsed: float = 0.0
var possession_elapsed: float = 0.0
var dead_clock: float = 0.0
var protection: float = 0.0
var rebound_delay: float = 0.0
var sound_clock: float = 0.0
var hud_clock: float = 0.0
var match_events: Array = []
var rng: RandomNumberGenerator = RandomNumberGenerator.new()
var autoplay: bool = false
var test_mode: bool = false
var solo_mode: bool = false
var hud
var sound
var arena: Node3D
var camera: Camera3D
var ball_mesh: MeshInstance3D
var ball_shadow: MeshInstance3D
var pass_indicator: Node3D
var input_direction: Vector3 = Vector3.ZERO
var last_pass_target: int = -1
var last_catch_target: int = -1

func _ready() -> void:
	rng.randomize()
	configure_input()
	teams = RosterStore.load_teams()
	test_mode = OS.get_cmdline_user_args().has("--test")
	solo_mode = OS.get_cmdline_user_args().has("--solo")
	autoplay = OS.get_cmdline_user_args().has("--autoplay")
	sound = Sound.new()
	add_child(sound)
	hud = load("res://scripts/hud.gd").new()
	add_child(hud)
	hud.play_requested.connect(start_match)
	hud.resume_requested.connect(resume_game)
	hud.pause_requested.connect(pause_game)
	hud.rematch_requested.connect(rematch)
	hud.menu_requested.connect(return_to_menu)
	hud.substitution_requested.connect(substitute)
	hud.roster_saved.connect(reload_rosters)
	build_world(false)
	hud.show_menu(teams)
	if solo_mode or autoplay:
		start_match(config)

func configure_input() -> void:
	var bindings: Dictionary = {
		"move_left":[KEY_A,KEY_LEFT], "move_right":[KEY_D,KEY_RIGHT],
		"move_up":[KEY_W,KEY_UP], "move_down":[KEY_S,KEY_DOWN],
		"sprint":[KEY_SHIFT], "shoot":[KEY_SPACE], "pass_steal":[KEY_E],
		"switch_player":[KEY_Q], "jump_block":[KEY_R], "crossover":[KEY_F], "between_legs":[KEY_C], "behind_back":[KEY_V], "pause_game":[KEY_ESCAPE]
	}
	for action: String in bindings:
		if not InputMap.has_action(action):
			InputMap.add_action(action, 0.2)
		for key: int in bindings[action]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			InputMap.action_add_event(action,event)
	var buttons: Dictionary = {"shoot":JOY_BUTTON_X,"pass_steal":JOY_BUTTON_A,"switch_player":JOY_BUTTON_LEFT_SHOULDER,"jump_block":JOY_BUTTON_Y,"crossover":JOY_BUTTON_B,"between_legs":JOY_BUTTON_RIGHT_SHOULDER,"behind_back":JOY_BUTTON_RIGHT_STICK,"pause_game":JOY_BUTTON_START}
	for action: String in buttons:
		var event := InputEventJoypadButton.new()
		event.button_index = buttons[action]
		InputMap.action_add_event(action,event)
	for binding: Array in [["move_left",JOY_AXIS_LEFT_X,-1.0],["move_right",JOY_AXIS_LEFT_X,1.0],["move_up",JOY_AXIS_LEFT_Y,-1.0],["move_down",JOY_AXIS_LEFT_Y,1.0],["sprint",JOY_AXIS_TRIGGER_RIGHT,1.0]]:
		var event := InputEventJoypadMotion.new()
		event.axis = binding[1]
		event.axis_value = binding[2]
		InputMap.action_add_event(binding[0], event)

func build_world(full: bool) -> void:
	if is_instance_valid(arena):
		remove_child(arena)
		arena.queue_free()
	arena = load("res://scripts/arena.gd").new()
	add_child(arena)
	arena.build(full)
	if not is_instance_valid(camera):
		camera = Camera3D.new()
		add_child(camera)
		camera.projection = Camera3D.PROJECTION_ORTHOGONAL
		camera.current = true
		camera.near = 0.1
		camera.far = 150.0
	camera.size = 20.0 if not full else 25.0
	camera.position = Vector3(0.0,17.5,17.0) if not full else Vector3(24.0,23.0,0.0)
	camera.look_at(Vector3(0,0,-0.6),Vector3.UP)
	if not is_instance_valid(ball_mesh):
		ball_mesh = MeshInstance3D.new()
		var mesh := SphereMesh.new()
		mesh.radius = BALL_RADIUS
		mesh.height = BALL_RADIUS * 2.0
		mesh.radial_segments = 20
		mesh.rings = 12
		ball_mesh.mesh = mesh
		var material := StandardMaterial3D.new()
		material.albedo_color = Color("e78032")
		material.roughness = 0.78
		ball_mesh.material_override = material
		add_child(ball_mesh)
		for rotation_axis: Vector3 in [Vector3.ZERO,Vector3(PI/2,0,0),Vector3(0,0,PI/2)]:
			var seam := MeshInstance3D.new()
			var seam_mesh := TorusMesh.new()
			seam_mesh.inner_radius = BALL_RADIUS - 0.002
			seam_mesh.outer_radius = BALL_RADIUS + 0.001
			seam_mesh.rings = 24
			seam_mesh.ring_segments = 4
			seam.mesh = seam_mesh
			var dark := StandardMaterial3D.new()
			dark.albedo_color = Color("48230e")
			seam.material_override = dark
			seam.rotation = rotation_axis
			ball_mesh.add_child(seam)
		ball_shadow = MeshInstance3D.new()
		var shadow := CylinderMesh.new()
		shadow.top_radius = 0.15
		shadow.bottom_radius = 0.15
		shadow.height = 0.008
		ball_shadow.mesh = shadow
		var shadow_mat := StandardMaterial3D.new()
		shadow_mat.albedo_color = Color(0.08,0.05,0.03,0.3)
		shadow_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		ball_shadow.material_override = shadow_mat
		add_child(ball_shadow)

func start_match(settings: Dictionary) -> void:
	config = settings.duplicate(true)
	config["home_index"] = clampi(int(config.get("home_index",0)),0,teams.size()-1)
	config["away_index"] = clampi(int(config.get("away_index",1)),0,teams.size()-1)
	if config.home_index == config.away_index:
		config.away_index = (config.home_index + 1) % teams.size()
	full_court = config.get("mode","half") == "full"
	court_limit = 14.0 if full_court else 7.0
	roster_size = 5 if full_court else 3
	build_world(full_court)
	for player in players:
		remove_child(player)
		player.queue_free()
	players.clear()
	selected_teams = [teams[config.home_index],teams[config.away_index]]
	for side: int in range(2):
		var team_data: Dictionary = selected_teams[side]
		for slot: int in range(roster_size):
			if solo_mode and (side > 0 or slot > 0):
				continue
			var player = Athlete.new()
			add_child(player)
			player.setup(team_data.players[slot],side,slot,Color(team_data.color),Color(team_data.trim))
			players.append(player)
	scores = [0,0]
	attempts = [0,0]
	makes = [0,0]
	steals = [0,0]
	blocks = [0,0]
	rebounds = [0,0]
	quarter = 1
	game_clock = float(config.get("quarter_seconds",60))
	elapsed = 0.0
	shot_id = 0
	resolved_shot_id = -1
	period_expired = false
	match_events.clear()
	last_pass_target = -1
	last_catch_target = -1
	shot_report.clear()
	phase = "live"
	hud.show_game()
	restart(0,"Opening possession",false)
	if solo_mode:
		phase = "live"
	update_hud()

func team_players(side: int) -> Array:
	return players.filter(func(player): return player.team == side)

func attack_sign(side: int) -> float:
	if not full_court:
		return -1.0
	var sign_value: float = -1.0 if side == 0 else 1.0
	return -sign_value if quarter >= 3 else sign_value

func basket(side: int) -> Vector3:
	return Vector3(0,3.05,(court_limit-1.2)*attack_sign(side))

func flat_distance(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x-b.x,a.z-b.z).length()

func beyond_arc(point: Vector3, side: int) -> bool:
	var hoop: Vector3 = basket(side)
	var baseline_distance: float = court_limit - absf(point.z)
	if baseline_distance < 3.0 and absf(point.x) > 6.35:
		return true
	return flat_distance(point,hoop) >= ARC_RADIUS

func nearest_player(pool: Array, point: Vector3):
	var best = null
	var best_distance: float = INF
	for player in pool:
		var distance: float = flat_distance(player.position,point)
		if distance < best_distance:
			best = player
			best_distance = distance
	return best

func restart(side: int, reason: String, after_score: bool = false) -> void:
	if solo_mode:
		side = 0
	possession_team = side
	last_touch_team = side
	needs_clear = false
	period_expired = false
	ball_owner = null
	passer = null
	receiver = null
	shooter = null
	ball_state = "held"
	protection = 0.85
	rebound_delay = 0.0
	possession_elapsed = 0.0
	shot_clock = 24.0 if full_court else 20.0
	var offense: Array = team_players(side)
	var defense: Array = team_players(1-side)
	var sign_value: float = attack_sign(side)
	var half_positions: Array = [Vector3(0,0,3.0),Vector3(-4.8,0,0.5),Vector3(4.8,0,0.5)]
	for i: int in range(offense.size()):
		var player = offense[i]
		player.reset_motion()
		if full_court:
			var z: float = -sign_value*(court_limit - 2.5) + sign_value * float(i) * 1.2
			player.position = Vector3(0 if i == 0 else (-4.0 if i % 2 == 0 else 4.0),0,z)
		else:
			player.position = half_positions[i]
		player.rotation.y = 0 if sign_value < 0 else PI
	for i: int in range(defense.size()):
		var player = defense[i]
		player.reset_motion()
		var opponent = offense[i % offense.size()]
		player.position = opponent.position + Vector3(0.3,0,sign_value * (4.8 if full_court else 1.65))
		player.rotation.y = PI if sign_value < 0 else 0
	ball_owner = offense[0]
	ball_owner.has_ball = true
	active = ball_owner if side == 0 else nearest_player(team_players(0),ball_owner.position)
	ball_position = ball_owner.hand_position()
	phase = "restart"
	dead_clock = 1.0 if not full_court else 1.1
	feedback("CHECK BALL" if not full_court else "INBOUND",reason)
	log_event("restart",{"team":side,"reason":reason,"made_basket":after_score})

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("pause_game") and not event.is_echo():
		if phase == "paused" or phase == "break":
			resume_game()
		elif phase in ["live","restart"]:
			pause_game()
		get_viewport().set_input_as_handled()
		return
	if phase != "live" or autoplay or active == null:
		return
	if event.is_action_pressed("shoot") and not event.is_echo():
		start_shot(active)
	elif event.is_action_released("shoot"):
		if active.charge >= 0.0:
			release_shot(active)
	elif event.is_action_pressed("pass_steal") and not event.is_echo():
		if ball_owner != null and ball_owner.team == 0:
			pass_ball(ball_owner,active if ball_owner != active else choose_pass_target(ball_owner,input_direction))
		else:
			try_steal(active)
	elif event.is_action_pressed("switch_player") and not event.is_echo():
		switch_control()
	elif event.is_action_pressed("jump_block") and not event.is_echo():
		active.jump()
	elif event.is_action_pressed("crossover") and not event.is_echo():
		crossover(active)
	elif event.is_action_pressed("between_legs") and not event.is_echo():
		crossover(active,"between")
	elif event.is_action_pressed("behind_back") and not event.is_echo():
		crossover(active,"behind")
	else:
		return
	get_viewport().set_input_as_handled()

func _physics_process(delta: float) -> void:
	step(delta)

func step(delta: float) -> void:
	if not phase in ["live","restart"]:
		return
	elapsed += delta
	protection = maxf(0.0,protection-delta)
	rebound_delay = maxf(0.0,rebound_delay-delta)
	hud_clock += delta
	if phase == "restart":
		dead_clock -= delta
		if dead_clock <= 0.0:
			if full_court:
				phase = "live"
				var target = team_players(possession_team)[1]
				pass_ball(ball_owner,target,true)
			else:
				phase = "live"
			feedback("PLAY", "Clear the arc after a defensive rebound or steal" if not full_court else "24-second possession")
	else:
		possession_elapsed += delta
		if full_court:
			game_clock = maxf(0.0,game_clock-delta)
			if game_clock == 0.0:
				period_expired = true
				if ball_state != "shot":
					finish_period()
					return
		if not period_expired:
			if ball_state in ["held","pass"]:
				shot_clock -= delta
				if shot_clock <= 0.0:
					restart(1-possession_team,"Shot clock violation")
					sound.play("whistle")
					return
			input_direction = read_movement()
			for player in players:
				player.selected = player == active
				player.has_ball = player == ball_owner
				player.defending = player.team != possession_team
				var direction: Vector3 = Vector3.ZERO
				var sprint: bool = false
				if player == active and not autoplay:
					direction = input_direction
					sprint = Input.is_action_pressed("sprint")
				else:
					var decision: Dictionary = ai_decision(player,delta)
					direction = decision.direction
					sprint = decision.sprint
				player.tick(direction,sprint,delta)
				if player.charge >= 0.0 and player == ball_owner:
					player.charge += delta / (0.65 if player.layup else 0.84)
					if player != active or autoplay:
						if player.charge >= player.desired_release:
							release_shot(player)
					elif player.charge >= 1.12:
						release_shot(player)
			separate_players()
			check_clear()
		update_ball(delta)
		if phase == "live" and not period_expired:
			check_out_of_bounds()
		if period_expired and ball_state != "shot":
			finish_period()
	if ball_owner != null and ball_state == "held":
		ball_position = ball_owner.hand_position()
		sound_clock += delta
		if sound_clock > 0.43 and ball_owner.charge < 0.0:
			sound_clock = 0.0
			sound.play("bounce")
	ball_mesh.position = ball_position
	ball_mesh.rotate_y(delta * 4.0)
	ball_shadow.position = Vector3(ball_position.x,0.014,ball_position.z)
	if full_court:
		var target_z: float = clampf(ball_position.z*0.13,-1.6,1.6)
		camera.position.z = lerpf(camera.position.z,target_z,delta*2.0)
		camera.look_at(Vector3(0,0,target_z),Vector3.UP)
	if hud_clock > 0.08:
		update_hud()
		hud_clock = 0.0

func read_movement() -> Vector3:
	var axis: Vector2 = Input.get_vector("move_left","move_right","move_up","move_down")
	var right: Vector3 = camera.global_basis.x
	var forward: Vector3 = -camera.global_basis.z
	right.y = 0.0
	forward.y = 0.0
	return right.normalized()*axis.x-forward.normalized()*axis.y

func separate_players() -> void:
	for i: int in range(players.size()):
		for j: int in range(i+1,players.size()):
			var a = players[i]
			var b = players[j]
			var offset: Vector3 = a.position-b.position
			offset.y = 0.0
			var distance: float = offset.length()
			if distance < 0.66:
				var normal: Vector3 = offset.normalized() if distance > 0.01 else Vector3.RIGHT
				var push: Vector3 = normal * (0.66-distance)*0.5
				a.position += push
				b.position -= push
	for player in players:
		player.position.x = clampf(player.position.x,-8.2,8.2)
		player.position.z = clampf(player.position.z,-court_limit-0.7,court_limit+0.7)

func shot_contest(player) -> float:
	var contest: float = 0.0
	var hoop: Vector3 = basket(player.team)
	var toward_hoop: Vector3 = (hoop-player.position).normalized()
	for defender in team_players(1-player.team):
		var distance: float = flat_distance(defender.position,player.position)
		if distance > 3.2:
			continue
		var relative: Vector3 = (defender.position-player.position).normalized()
		var in_front: float = 1.0 if relative.dot(toward_hoop) > -0.3 else 0.58
		var pressure: float = clampf(1.0-distance/3.2,0.0,1.0) * in_front
		pressure *= 0.7 + defender.rating("defense") / 200.0
		pressure += 0.22 if defender.jump_height > 0.2 and distance < 2.3 else 0.0
		contest = maxf(contest,pressure)
	return clampf(contest,0.0,1.0)

func evaluate_shot(rating_value: float, release: float, distance: float, contest: float, layup: bool) -> Dictionary:
	var error: float = absf(release-0.72)
	var window: float = 0.025 + rating_value * 0.00065
	var green: bool = error <= window
	var chance: float = (0.49 + rating_value * 0.0047) if layup else (0.35 + rating_value * 0.0048)
	var range_penalty: float = maxf(0.0,distance-(1.8 if layup else 4.5)) * (0.045 if layup else 0.075)
	if distance > 8.0:
		range_penalty += (distance-8.0)*0.11
	chance -= range_penalty
	chance -= maxf(0.0,error-window) * (1.35 if layup else 1.95)
	chance *= 1.0-contest*(0.61 if layup else 0.78)
	if green:
		chance += 0.10 * (1.0-contest)
	chance = clampf(chance,0.015,0.985)
	var timing: String = "Excellent"
	if not green:
		if error < 0.18:
			timing = "Slightly Early" if release < 0.72 else "Slightly Late"
		else:
			timing = "Early" if release < 0.72 else "Late"
	var coverage: String = "Wide Open"
	if contest > 0.65:
		coverage = "Heavily Contested"
	elif contest > 0.30:
		coverage = "Contested"
	elif contest > 0.10:
		coverage = "Lightly Contested"
	return {"chance":chance,"green":green,"window":window,"timing":timing,"coverage":coverage,"contest":contest,"distance":distance,"layup":layup,"rating":rating_value}

func start_shot(player) -> bool:
	if phase != "live" or player != ball_owner or ball_state != "held" or player.charge >= 0.0:
		return false
	if needs_clear:
		if player == active:
			feedback("CLEAR THE BALL", "Take possession beyond the arc before shooting")
		return false
	player.layup = flat_distance(player.position,basket(player.team)) < 2.7
	player.charge = 0.0
	player.rotation.y = atan2(-(basket(player.team).x-player.position.x),-(basket(player.team).z-player.position.z))
	var skill: float = player.rating("finishing" if player.layup else "shooting")
	var spread: float = 0.13-skill*0.0008
	spread *= [1.4,1.0,0.78][clampi(int(config.get("difficulty",1)),0,2)]
	player.desired_release = clampf(rng.randfn(0.72,spread),0.40,1.03)
	return true

func release_shot(player) -> bool:
	if phase != "live" or player != ball_owner or ball_state != "held" or player.charge < 0.0 or needs_clear:
		return false
	var hoop: Vector3 = basket(player.team)
	var distance: float = flat_distance(player.position,hoop)
	shot_report = evaluate_shot(player.rating("finishing" if player.layup else "shooting"),player.charge,distance,shot_contest(player),player.layup)
	planned_make = rng.randf() < float(shot_report.chance)
	shot_id += 1
	shooter = player
	shot_points = (3 if full_court else 2) if beyond_arc(player.position,player.team) else (2 if full_court else 1)
	attempts[player.team] += 1
	ball_origin = player.position + Vector3(0.0,1.85+player.jump_height,0.0)
	ball_target = hoop
	if not planned_make:
		var miss_angle: float = rng.randf_range(0.0,TAU)
		var miss_distance: float = rng.randf_range(0.42,0.72)
		ball_target += Vector3(cos(miss_angle),0,sin(miss_angle))*miss_distance
	flight_duration = clampf(0.72+distance*0.046,0.75,1.65)
	ball_velocity = (ball_target-ball_origin)/flight_duration + Vector3.UP*(0.5*GRAVITY*flight_duration)
	ball_position = ball_origin
	ball_elapsed = 0.0
	ball_state = "shot"
	ball_owner = null
	player.has_ball = false
	player.charge = -1.0
	player.follow_through = 0.65
	player.jump_timer = 0.67
	player.action_cooldown = 0.8
	feedback(str(shot_report.timing),str(shot_report.coverage)+" · "+("Layup" if player.layup else "Jump shot"),bool(shot_report.green))
	log_event("shot",{"team":player.team,"id":shot_id,"points":shot_points,"chance":shot_report.chance,"release":shot_report.timing})
	return true

func choose_pass_target(player, direction: Vector3):
	var best = null
	var best_score: float = -INF
	for teammate in team_players(player.team):
		if teammate == player:
			continue
		var offset: Vector3 = teammate.position-player.position
		var openness: float = 4.0
		var defender = nearest_player(team_players(1-player.team),teammate.position)
		if defender != null:
			openness = flat_distance(defender.position,teammate.position)
		var alignment: float = offset.normalized().dot(direction.normalized()) if direction.length() > 0.1 else 0.0
		var ranking: float = openness * 0.7 - offset.length()*0.06 + alignment*6.0
		if needs_clear and beyond_arc(teammate.position,player.team):
			ranking += 3.0
		if ranking > best_score:
			best = teammate
			best_score = ranking
	return best

func pass_ball(from_player, to_player, inbound: bool = false) -> bool:
	if from_player == null or to_player == null or from_player == to_player or ball_owner != from_player or ball_state != "held" or from_player.team != to_player.team:
		return false
	if not phase in ["live","restart"]:
		return false
	passer = from_player
	from_player.pass_pose = 0.28
	receiver = to_player
	last_pass_target = int(to_player.slot)
	last_catch_target = -1
	ball_origin = from_player.position+Vector3.UP*1.25
	ball_target = to_player.position+Vector3.UP*1.2
	var speed: float = 13.0+from_player.rating("passing")*0.085
	flight_duration = clampf(flat_distance(ball_origin,ball_target)/speed,0.13,1.4)
	ball_elapsed = 0.0
	ball_state = "pass"
	ball_owner.has_ball = false
	ball_owner.charge = -1.0
	ball_owner = null
	protection = 0.45 if inbound else minf(protection,0.15)
	sound.play("pass")
	log_event("pass",{"team":from_player.team,"target":to_player.slot,"inbound":inbound})
	return true

func take_possession(player, turnover: bool = false) -> void:
	var changed_team: bool = player.team != possession_team
	if ball_owner != null:
		ball_owner.has_ball = false
		ball_owner.charge = -1.0
	ball_owner = player
	ball_owner.has_ball = true
	ball_owner.charge = -1.0
	possession_team = player.team
	last_touch_team = player.team
	ball_state = "held"
	ball_position = player.hand_position()
	ball_velocity = Vector3.ZERO
	protection = 0.65
	if changed_team or turnover:
		needs_clear = not full_court
		shot_clock = 24.0 if full_court else 20.0
		possession_elapsed = 0.0
		feedback("CLEAR THE BALL" if needs_clear else "TURNOVER", "Take it beyond the arc" if needs_clear else "Push the break")
	active = player if player.team == 0 else nearest_player(team_players(0),player.position)
	check_clear()

func check_clear() -> void:
	if needs_clear and ball_owner != null and beyond_arc(ball_owner.position,ball_owner.team) and ball_owner.position.z > basket(ball_owner.team).z:
		needs_clear = false
		feedback("BALL CLEARED","Attack the basket",true)
		log_event("clear",{"team":ball_owner.team})

func try_steal(player) -> bool:
	# Team 1 is the CPU opposition in both game modes.
	if player.team == 1:
		return false
	if phase != "live" or ball_owner == null or player.team == ball_owner.team or player.action_cooldown > 0.0 or ball_state != "held":
		return false
	player.action_cooldown = 0.85
	if protection > 0.0 or ball_owner.crossover_timer > 0.0 or flat_distance(player.position,ball_owner.position) > 1.38:
		return false
	var chance: float = clampf(0.32+(player.rating("defense")-ball_owner.rating("handling"))*0.004,0.10,0.62)
	if rng.randf() >= chance:
		if player == active:
			feedback("REACH MISSED","Recover your defensive position")
		return false
	steals[player.team] += 1
	take_possession(player,true)
	log_event("steal",{"team":player.team})
	return true

func crossover(player, kind: String = "cross") -> bool:
	if player != ball_owner or phase!="live":
		return false
	player.has_ball = true
	if not player.begin_dribble_move(kind):
		return false
	sound.play("squeak",-2.0)
	if player==active:
		feedback({"cross":"CROSSOVER","between":"BETWEEN THE LEGS","behind":"BEHIND THE BACK"}.get(kind,"CROSSOVER"),"Left hand" if player.hand<0 else "Right hand")
	return true

func switch_control() -> void:
	var home_players: Array = team_players(0)
	if home_players.size() < 2:
		return
	var candidates: Array = home_players.filter(func(player): return player != active)
	active = nearest_player(candidates,ball_position)

func update_ball(delta: float) -> void:
	if ball_state == "shot":
		ball_elapsed += delta
		var t: float = minf(ball_elapsed,flight_duration)
		ball_position = ball_origin+ball_velocity*t+Vector3.DOWN*0.5*GRAVITY*t*t
		if ball_elapsed < flight_duration*0.6 and check_block():
			return
		if ball_elapsed >= flight_duration:
			resolve_shot()
	elif ball_state == "pass":
		ball_elapsed += delta
		if receiver == null:
			make_loose(Vector3.DOWN,0.2)
			return
		ball_target = receiver.position+Vector3.UP*1.2
		var progress: float = clampf(ball_elapsed/flight_duration,0.0,1.0)
		ball_position = ball_origin.lerp(ball_target,progress)+Vector3.UP*(sin(progress*PI)*0.35)
		if passer.team == 1 and protection <= 0.0 and progress > 0.15 and progress < 0.90:
			for defender in team_players(1-passer.team):
				if flat_distance(defender.position,ball_position) < 0.47 and ball_position.y < 2.0+defender.jump_height:
					steals[defender.team] += 1
					take_possession(defender,true)
					log_event("interception",{"team":defender.team})
					return
		if progress >= 1.0:
			last_catch_target = receiver.slot
			take_possession(receiver)
	elif ball_state == "loose":
		ball_velocity.y -= GRAVITY*delta
		ball_position += ball_velocity*delta
		if ball_position.y < BALL_RADIUS:
			ball_position.y = BALL_RADIUS
			ball_velocity.y = absf(ball_velocity.y)*0.61
			ball_velocity.x *= 0.78
			ball_velocity.z *= 0.78
			sound.play("bounce",-2.0)
		if rebound_delay <= 0.0:
			try_rebound()
	elif ball_state == "made":
		ball_elapsed += delta
		ball_position += Vector3.DOWN*delta*3.0

func check_block() -> bool:
	if shooter == null:
		return false
	for defender in team_players(1-shooter.team):
		if defender.jump_height < 0.18:
			continue
		var hand_height: float = float(defender.data.get("height",1.9))+0.35+defender.jump_height
		if flat_distance(defender.position,ball_position) < 0.80 and absf(ball_position.y-hand_height) < 0.75:
			blocks[defender.team] += 1
			last_touch_team = defender.team
			var direction: Vector3 = (ball_position-defender.position).normalized()
			make_loose(direction*4.0+Vector3.UP*2.0,0.18)
			feedback("BLOCKED","Find the loose ball",defender.team==0)
			log_event("block",{"team":defender.team,"shot":shot_id})
			return true
	return false

func resolve_shot() -> void:
	if resolved_shot_id == shot_id or ball_state != "shot" or shooter == null:
		return
	resolved_shot_id = shot_id
	if planned_make:
		var side: int = shooter.team
		scores[side] += shot_points
		makes[side] += 1
		ball_state = "made"
		ball_elapsed = 0.0
		sound.play("make")
		log_event("basket",{"team":side,"points":shot_points,"shot":shot_id})
		feedback("+%d %s" % [shot_points,selected_teams[side].abbr],"Clean finish",side==0)
		if not full_court and scores[side] >= TARGET_SCORE:
			finish_match()
		elif not period_expired:
			restart(1-side,"Basket · Opponent's ball",true)
	else:
		sound.play("rim")
		var hoop: Vector3 = basket(shooter.team)
		var inward: Vector3 = Vector3(rng.randf_range(-1.0,1.0),0,-attack_sign(shooter.team)).normalized()
		ball_position = Vector3(ball_target.x,hoop.y,ball_target.z)
		make_loose(inward*rng.randf_range(2.2,4.7)+Vector3.UP*rng.randf_range(1.5,2.7),0.2)
		feedback("OFF THE RIM","Time your jump for the rebound")

func make_loose(velocity_value: Vector3, delay: float) -> void:
	ball_state = "loose"
	ball_velocity = velocity_value
	rebound_delay = delay
	ball_owner = null
	for player in players:
		player.charge = -1.0
		player.has_ball = false

func try_rebound() -> void:
	var candidate = null
	var best_score: float = -INF
	for player in players:
		var distance: float = flat_distance(player.position,ball_position)
		var reach: float = 0.64+player.rating("rebounding")*0.003
		var height: float = 1.0+player.jump_height+float(player.data.get("height",1.9))*0.38
		if distance < reach and ball_position.y < height:
			var value: float = player.rating("rebounding")*0.01+player.jump_height*0.7-distance
			if value > best_score:
				candidate = player
				best_score = value
	if candidate == null:
		return
	var changed: bool = candidate.team != possession_team
	rebounds[candidate.team] += 1
	take_possession(candidate,changed)
	shot_clock = (24.0 if changed else 14.0) if full_court else 20.0
	log_event("rebound",{"team":candidate.team,"defensive":changed})
	if not changed:
		feedback("OFFENSIVE REBOUND","Second chance",candidate.team==0)

func check_out_of_bounds() -> void:
	var position_to_check: Vector3 = ball_owner.position if ball_owner != null else ball_position
	if absf(position_to_check.x) > 7.65 or absf(position_to_check.z) > court_limit+0.15:
		var next_team: int = 1-last_touch_team
		restart(next_team,"Out of bounds")
		sound.play("whistle")
		log_event("out_of_bounds",{"team":next_team})

func ai_decision(player, _delta: float) -> Dictionary:
	var target: Vector3 = player.position
	var sprint: bool = false
	var hoop: Vector3 = basket(player.team)
	var sign_value: float = attack_sign(player.team)
	if ball_state == "loose":
		var lead: Vector3 = ball_position+ball_velocity*0.20
		lead.x = clampf(lead.x,-7.1,7.1)
		lead.z = clampf(lead.z,-court_limit+0.4,court_limit-0.4)
		target = lead
		sprint = true
		if flat_distance(player.position,ball_position) < 1.1 and ball_position.y > 1.5 and ball_velocity.y < 0:
			player.jump()
	elif ball_state == "shot":
		var shot_hoop: Vector3 = basket(shooter.team)
		var lane: float = float(player.slot % 3 - 1)*1.1
		target = shot_hoop+Vector3(lane,-shot_hoop.y,-attack_sign(shooter.team)*1.7)
	elif ball_owner == player:
		if player.charge >= 0.0:
			return {"direction":Vector3.ZERO,"sprint":false}
		var distance: float = flat_distance(player.position,hoop)
		var nearest = nearest_player(team_players(1-player.team),player.position)
		var gap: float = flat_distance(nearest.position,player.position) if nearest != null else 6.0
		if needs_clear:
			target = Vector3(clampf(player.position.x,-4.5,4.5),0,3.0)
			sprint = true
		elif (distance < 2.6 and possession_elapsed > 0.65) or (distance < 7.0 and gap > 1.85 and possession_elapsed > 1.8) or shot_clock < 1.8 or (full_court and game_clock < 1.2):
			start_shot(player)
		elif player.decision_timer <= 0.0:
			player.decision_timer = rng.randf_range(0.6,1.15)
			var teammate = choose_pass_target(player,Vector3.ZERO)
			if teammate != null and gap < 1.7 and possession_elapsed > 1.0:
				var defender = nearest_player(team_players(1-player.team),teammate.position)
				var team_gap: float = flat_distance(defender.position,teammate.position) if defender != null else 6.0
				if team_gap > gap+0.6 and flat_distance(teammate.position,hoop) < distance+1.5:
					pass_ball(player,teammate)
			if player == ball_owner and gap < 1.5:
				crossover(player)
		if not needs_clear:
			var lane: float = (1.5 if player.slot%2 == 0 else -1.5)
			target = Vector3(lane,0,hoop.z-sign_value*1.6)
			sprint = distance > 7.5 or (gap > 2.1 and player.stamina > 25.0)
	elif ball_owner != null and player.team == ball_owner.team:
		var lanes: Array[float] = [0.0,-5.4,5.4,-3.4,3.4]
		var slot: int = player.slot
		var depth: float = [7.0,5.0,5.0,2.0,2.0][slot]
		var desired_z: float = hoop.z-sign_value*depth
		if full_court and flat_distance(ball_owner.position,hoop) > 11.0:
			desired_z = ball_owner.position.z+sign_value*(3.0+slot*0.4)
			sprint = true
		var cutter: int = int(elapsed / 5.5) % roster_size
		if slot == cutter and ball_owner.slot != slot and fmod(elapsed,5.5) > 2.2 and not needs_clear:
			desired_z = hoop.z-sign_value*1.6
			target = Vector3(-1.4 if player.position.x < 0 else 1.4,0,desired_z)
			sprint = true
		else:
			target = Vector3(lanes[slot],0,desired_z)
		if needs_clear:
			target.z = 3.0
	elif ball_owner != null:
		var offense: Array = team_players(ball_owner.team)
		var assignment = offense[player.slot % offense.size()]
		var attack_hoop: Vector3 = basket(ball_owner.team)
		var toward_rim: Vector3 = attack_hoop-assignment.position
		toward_rim.y = 0.0
		var cushion: float = 1.0 if assignment == ball_owner else 1.5
		target = assignment.position+toward_rim.normalized()*cushion
		sprint = flat_distance(player.position,target) > 3.0
		if assignment == ball_owner:
			var gap: float = flat_distance(player.position,ball_owner.position)
			if ball_owner.charge > 0.45 and gap < 2.0:
				player.jump()
			elif player.team == 0 and gap < 1.35 and player.decision_timer <= 0.0:
				player.decision_timer = rng.randf_range(0.8,1.8)
				try_steal(player)
	elif ball_state == "pass" and receiver != null:
		if player == receiver:
			target = player.position
		elif player.team != receiver.team:
			var opponents: Array = team_players(receiver.team)
			var opponent = opponents[player.slot % opponents.size()]
			target = opponent.position+(basket(receiver.team)-opponent.position).normalized()
	target.y = 0.0
	target.x = clampf(target.x,-7.0,7.0)
	target.z = clampf(target.z,-court_limit+0.5,court_limit-0.5)
	var direction: Vector3 = target-player.position
	direction.y = 0.0
	if direction.length() < 0.20:
		direction = Vector3.ZERO
	else:
		direction = direction.normalized()
	return {"direction":direction,"sprint":sprint}

func pause_game() -> void:
	if phase not in ["live","restart"]:
		return
	previous_phase = phase
	phase = "paused"
	if ball_owner != null:
		ball_owner.charge = -1.0
	hud.set_meter(0.0,0.72,0.1,false)
	update_hud()
	hud.show_pause()

func resume_game() -> void:
	if phase == "break":
		quarter += 1
		game_clock = float(config.get("quarter_seconds",60)) if quarter <= 4 else 60.0
		period_expired = false
		hud.show_game()
		restart((quarter+1)%2,"Quarter %d" % quarter if quarter <= 4 else "Overtime")
	elif phase == "paused":
		phase = previous_phase
		hud.show_game()
	update_hud()

func finish_period() -> void:
	if phase == "final" or phase == "break":
		return
	if quarter >= 4 and scores[0] != scores[1]:
		finish_match()
		return
	phase = "break"
	for player in players:
		player.charge = -1.0
	hud.set_meter(0.0,0.72,0.1,false)
	var title: String = "HALFTIME" if quarter == 2 else "QUARTER COMPLETE"
	if quarter >= 4:
		title = "OVERTIME"
	hud.show_break(title,"%s %d  —  %d %s" % [selected_teams[0].abbr,scores[0],scores[1],selected_teams[1].abbr])
	sound.play("whistle")
	log_event("period_end",{"quarter":quarter})
	update_hud()

func finish_match() -> void:
	phase = "final"
	for player in players:
		player.charge = -1.0
	var winner: int = 0 if scores[0] > scores[1] else 1
	var heading: String = "%s WIN" % str(selected_teams[winner].name).to_upper()
	hud.set_meter(0.0,0.72,0.1,false)
	hud.show_result(heading,"%s %d  —  %d %s\nYou control %s" % [selected_teams[0].abbr,scores[0],scores[1],selected_teams[1].abbr,selected_teams[0].name])
	log_event("final",{"scores":scores.duplicate(),"winner":winner})
	update_hud()

func rematch() -> void:
	start_match(config)

func return_to_menu() -> void:
	phase = "menu"
	if ball_owner != null:
		ball_owner.charge = -1.0
	hud.set_meter(0.0,0.72,0.1,false)
	reload_rosters()
	hud.show_menu(teams)

func reload_rosters() -> void:
	teams = RosterStore.load_teams()

func bench_players() -> Array:
	if selected_teams.is_empty():
		return []
	var used: Array = team_players(0).map(func(player): return player.roster_index)
	var bench: Array = []
	var roster: Array = selected_teams[0].players
	for i: int in range(roster.size()):
		if i not in used:
			bench.append({"name":roster[i].name,"number":roster[i].number,"slot":i})
	return bench

func substitute(roster_index: int) -> void:
	if phase not in ["paused","break","restart"] or selected_teams.is_empty():
		return
	var roster: Array = selected_teams[0].players
	if roster_index < 0 or roster_index >= roster.size():
		return
	if team_players(0).any(func(player): return player.roster_index == roster_index):
		return
	var outgoing = active if active != null and active.team == 0 else team_players(0)[0]
	var replacement = Athlete.new()
	add_child(replacement)
	replacement.setup(roster[roster_index],0,outgoing.slot,Color(selected_teams[0].color),Color(selected_teams[0].trim))
	replacement.roster_index = roster_index
	replacement.position = outgoing.position
	replacement.rotation = outgoing.rotation
	replacement.has_ball = outgoing == ball_owner
	if outgoing == ball_owner:
		ball_owner = replacement
	if outgoing == receiver:
		receiver = replacement
	if outgoing == passer:
		passer = replacement
	if outgoing == shooter:
		shooter = replacement
	players[players.find(outgoing)] = replacement
	active = replacement
	remove_child(outgoing)
	outgoing.queue_free()
	feedback("SUBSTITUTION",str(replacement.data.name)+" checks in")
	log_event("substitution",{"player":replacement.data.name})
	update_hud()

func feedback(message: String, detail: String = "", good: bool = false) -> void:
	if hud != null:
		hud.show_feedback(message,detail,good)

func log_event(kind: String, data: Dictionary = {}) -> void:
	var entry: Dictionary = data.duplicate(true)
	entry["event"] = kind
	entry["time"] = elapsed
	match_events.append(entry)
	if test_mode:
		print("EVENT ",JSON.stringify(entry))

func update_hud() -> void:
	if selected_teams.is_empty():
		return
	var seconds: int = ceili(game_clock)
	var clock_text: String = "%d:%02d" % [seconds/60,seconds%60]
	var player_text: String = str(active.data.name) if active != null else ""
	var stats_text: String = "FG %d/%d · REB %d · STL %d · BLK %d" % [makes[0],attempts[0],rebounds[0],steals[0],blocks[0]]
	if active != null:
		stats_text += " · ENERGY %d%%" % int(active.stamina)
	var quarter_text: String = "Q%d" % quarter if quarter <= 4 else "OT%d" % (quarter-4)
	hud.update_game({"home":selected_teams[0],"away":selected_teams[1],"scores":scores,"phase":phase,"possession":str(selected_teams[possession_team].abbr)+" possession","player":player_text,"stats":stats_text,"mode":"full" if full_court else "half","clock":clock_text,"shot_clock":str(maxi(0,ceili(shot_clock))),"quarter":quarter_text,"clear_required":needs_clear,"can_substitute":phase in ["paused","break","restart"],"bench":bench_players()})
	if active != null and active.charge >= 0.0 and ball_owner == active:
		var skill: float = active.rating("finishing" if active.layup else "shooting")
		hud.set_meter(active.charge,0.72,0.025+skill*0.00065,true)
	else:
		hud.set_meter(0.0,0.72,0.1,false)

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT and not test_mode and not autoplay:
		pause_game()
