extends Node3D

# Procedural court art. The game owns rules, camera, ball and player collisions.
var _materials: Dictionary = {}

func build(full_court: bool = false) -> void:
	for child in get_children():
		remove_child(child)
		child.queue_free()
	var court_length: float = 28.0 if full_court else 14.0
	var baseline: float = -court_length * 0.5
	var hoop_z: float = baseline + 1.2
	_create_lighting()
	_box("Arena floor", Vector3(26.0, 0.2, court_length + 13.0), Vector3(0, -0.22, 0), _material("concourse", Color("121b28")))
	_box("Court border", Vector3(18.0, 0.14, court_length + 2.6), Vector3(0, -0.12, 0), _material("border", Color("182f3b")))
	_box("Court surface", Vector3(15.0, 0.12, court_length), Vector3(0, -0.06, 0), _material("wood", Color("d9ac74")))
	_add_parquet(court_length)
	var floor_body := StaticBody3D.new()
	floor_body.name = "FloorCollision"
	var floor_shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = Vector3(40, 0.2, court_length + 20)
	floor_shape.shape = box_shape
	floor_shape.position.y = -0.12
	floor_body.add_child(floor_shape)
	add_child(floor_body)
	var white := _material("line", Color("f2eee0"))
	var paint := _material("paint", Color("276370"))
	_floor_line(Vector3(-7.5, 0, baseline), Vector3(7.5, 0, baseline), 0.05, white)
	_floor_line(Vector3(-7.5, 0, -baseline), Vector3(7.5, 0, -baseline), 0.05, white)
	_floor_line(Vector3(-7.5, 0, baseline), Vector3(-7.5, 0, -baseline), 0.05, white)
	_floor_line(Vector3(7.5, 0, baseline), Vector3(7.5, 0, -baseline), 0.05, white)
	_add_end(baseline, 1.0, white, paint)
	_create_hoop(hoop_z, 1.0)
	if full_court:
		_add_end(-baseline, -1.0, white, paint)
		_create_hoop(-hoop_z, -1.0)
		_floor_line(Vector3(-7.5, 0, 0), Vector3(7.5, 0, 0), 0.045, white)
		_floor_arc(Vector3.ZERO, 1.8, 0, TAU, white)
		_floor_brand(Vector3(0, 0.035, 0), "UC", 0.013, Color("214d59"))
	else:
		_floor_arc(Vector3(0, 0, 7), 1.8, PI * 0.5, PI * 1.5, white)
		_floor_brand(Vector3(0, 0.035, 4.9), "UPCOURT", 0.009, Color("244c56"))
	_floor_brand(Vector3(0, 0.03, baseline - 0.65), "PICKUP   /   PROVING GROUND", 0.004, Color("c6e4e7"))
	_add_stands(court_length)
	_add_arena_detail(court_length)

func _create_lighting() -> void:
	var environment := WorldEnvironment.new()
	var settings := Environment.new()
	settings.background_mode = Environment.BG_COLOR
	settings.background_color = Color("101724")
	settings.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	settings.ambient_light_color = Color("d5e4ee")
	settings.ambient_light_energy = 0.28
	settings.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.environment = settings
	add_child(environment)
	var key := DirectionalLight3D.new()
	key.rotation_degrees = Vector3(-65, -35, 0)
	key.light_color = Color("fff0dc")
	key.light_energy = 0.65
	key.shadow_enabled = true
	key.directional_shadow_max_distance = 65
	add_child(key)
	var fill := DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-28, 140, 0)
	fill.light_color = Color("b9dcea")
	fill.light_energy = 0.16
	add_child(fill)

func _add_parquet(length: float) -> void:
	var generator := RandomNumberGenerator.new()
	generator.seed = 87312
	var rows: int = int(ceil(length / 0.4))
	for row in range(rows):
		var z: float = -length * 0.5 + float(row) * 0.4
		for column in range(6):
			var shade: float = generator.randf_range(0.76, 1.0)
			var material := StandardMaterial3D.new()
			material.albedo_color = Color(0.52 * shade, 0.32 * shade, 0.15 * shade)
			material.roughness = 0.9
			_box("Hardwood plank", Vector3(2.494,0.008,minf(0.395,length*0.5-z)),Vector3(-6.25+column*2.5,0.004,z+0.2),material)

func _add_end(baseline: float, direction: float, white: Material, paint: Material) -> void:
	var rim_z: float = baseline + direction * 1.2
	var free_throw: float = baseline + direction * 5.8
	_box("Paint", Vector3(4.88, 0.012, 5.8), Vector3(0, 0.015, baseline + direction * 2.9), paint)
	for x: float in [-2.44, 2.44]:
		_floor_line(Vector3(x, 0, baseline), Vector3(x, 0, free_throw), 0.05, white)
		for step in range(4):
			var z: float = baseline + direction * (1.75 + float(step) * 0.9)
			_floor_line(Vector3(x, 0, z), Vector3(x + signf(x) * 0.25, 0, z), 0.045, white)
	_floor_line(Vector3(-2.44, 0, free_throw), Vector3(2.44, 0, free_throw), 0.05, white)
	var offset: float = 0.0 if direction > 0 else PI
	_floor_arc(Vector3(0, 0, free_throw), 1.8, -PI * 0.5 + offset, PI * 0.5 + offset, white)
	_floor_arc(Vector3(0, 0, free_throw), 1.8, PI * 0.5 + offset, PI * 1.5 + offset, white, true)
	_floor_arc(Vector3(0, 0, rim_z), 1.25, -PI * 0.5 + offset, PI * 0.5 + offset, white)
	var angle: float = asin(6.6 / 6.75)
	_floor_arc(Vector3(0, 0, rim_z), 6.75, -angle + offset, angle + offset, white)
	var corner_z: float = rim_z + direction * cos(angle) * 6.75
	for x: float in [-6.6, 6.6]:
		_floor_line(Vector3(x, 0, baseline), Vector3(x, 0, corner_z), 0.05, white)

func _create_hoop(rim_z: float, direction: float) -> void:
	var pole := _material("pole", Color("344759"), 0.45)
	var frame := _material("frame", Color("e7ebee"), 0.3)
	var orange := _material("orange", Color("f7833e"), 0.4)
	var net := _material("net", Color("dce4e4"))
	var support_z: float = rim_z - direction * 2.7
	_box("Basket base", Vector3(1.4, 0.36, 1.45), Vector3(0, 0.18, support_z), _material("pad", Color("123b4b")))
	_beam(Vector3(0, 0.3, support_z), Vector3(0, 3.5, support_z), 0.16, pole)
	_beam(Vector3(0, 3.5, support_z), Vector3(0, 3.48, rim_z - direction * 0.46), 0.14, pole)
	var board_z: float = rim_z - direction * 0.38
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.58, 0.77, 0.83, 0.27)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.roughness = 0.18
	glass.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_box("Glass backboard", Vector3(1.82, 1.05, 0.045), Vector3(0, 3.58, board_z), glass)
	for x: float in [-0.91, 0.91]:
		_box("Backboard frame", Vector3(0.035, 1.08, 0.055), Vector3(x, 3.58, board_z), frame)
	for y: float in [3.055, 4.105]:
		_box("Backboard frame", Vector3(1.85, 0.035, 0.055), Vector3(0, y, board_z), frame)
	for x: float in [-0.3, 0.3]:
		_box("Target box", Vector3(0.025, 0.45, 0.055), Vector3(x, 3.31, board_z + direction * 0.03), frame)
	for y: float in [3.085, 3.535]:
		_box("Target box", Vector3(0.62, 0.025, 0.055), Vector3(0, y, board_z + direction * 0.03), frame)
	_box("Rim bracket", Vector3(0.18, 0.055, 0.27), Vector3(0, 3.05, rim_z - direction * 0.2), orange)
	var ring := TorusMesh.new()
	ring.inner_radius = 0.218
	ring.outer_radius = 0.248
	ring.rings = 32
	ring.ring_segments = 8
	var rim := MeshInstance3D.new()
	rim.name = "Rim"
	rim.mesh = ring
	rim.material_override = orange
	rim.position = Vector3(0, 3.05, rim_z)
	add_child(rim)
	for index in range(12):
		var angle: float = float(index) / 12.0 * TAU
		var top := Vector3(cos(angle) * 0.225, 3.03, rim_z + sin(angle) * 0.225)
		for offset: float in [-0.25, 0.25]:
			var bottom := Vector3(cos(angle + offset) * 0.14, 2.64, rim_z + sin(angle + offset) * 0.14)
			_beam(top, bottom, 0.007, net)

func _add_stands(length: float) -> void:
	var seat := _material("seats", Color("2b384b"))
	var riser := _material("risers", Color("141d2c"))
	var rail := _material("rail", Color("68838d"), 0.6)
	var teal := _material("LED teal", Color("4ab7b6"), 0.5, true)
	var orange := _material("LED amber", Color("f7a15e"), 0.5, true)
	for side: float in [-1.0, 1.0]:
		for row in range(4):
			var x: float = side * (10.2 + float(row) * 0.85)
			var height: float = 0.35 + float(row) * 0.44
			_box("Bleacher tier", Vector3(0.86, height, length + 3), Vector3(x, height * 0.5, 0), riser)
			for index in range(int(length / 0.74)):
				var z: float = -length * 0.5 + float(index) * 0.74
				_box("Seat", Vector3(0.49, 0.09, 0.51), Vector3(x, height + 0.26, z), seat)
				_box("Seat back", Vector3(0.07, 0.47, 0.51), Vector3(x + side * 0.19, height + 0.48, z), seat)
		_box("Sideline LED", Vector3(0.1, 0.58, length + 0.6), Vector3(side * 9.2, 0.32, 0), teal if side < 0 else orange)
		_beam(Vector3(side * 9.65, 1.3, -length * 0.5), Vector3(side * 9.65, 1.3, length * 0.5), 0.035, rail)
	var back_z: float = -length * 0.5 - 4.8
	_box("Arena back wall", Vector3(29, 5, 0.2), Vector3(0, 2.2, back_z), _material("wall", Color("172231")))
	_box("Wall light", Vector3(24, 0.045, 0.08), Vector3(0, 3.6, back_z + 0.16), teal)
	var brand := Label3D.new()
	brand.text = "UPCOURT"
	brand.font_size = 128
	brand.pixel_size = 0.012
	brand.modulate = Color("d7f2ef")
	brand.outline_size = 0
	brand.position = Vector3(0, 2.4, back_z + 0.2)
	add_child(brand)

func _material(key: String, color: Color, roughness: float = 0.75, glow: bool = false) -> StandardMaterial3D:
	if _materials.has(key):
		return _materials[key]
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = roughness
	if glow:
		material.emission_enabled = true
		material.emission = color
		material.emission_energy_multiplier = 0.45
	_materials[key] = material
	return material

func _box(label: String, size: Vector3, center: Vector3, material: Material) -> MeshInstance3D:
	var result := MeshInstance3D.new()
	result.name = label
	var mesh := BoxMesh.new()
	mesh.size = size
	result.mesh = mesh
	result.material_override = material
	result.position = center
	add_child(result)
	return result

func _beam(start: Vector3, end: Vector3, radius: float, material: Material) -> void:
	var result := MeshInstance3D.new()
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = radius
	cylinder.bottom_radius = radius
	cylinder.height = start.distance_to(end)
	cylinder.radial_segments = 6
	result.mesh = cylinder
	result.material_override = material
	result.position = (start + end) * 0.5
	var direction: Vector3 = (end - start).normalized()
	result.quaternion = Quaternion(Vector3.UP, direction)
	add_child(result)

func _floor_line(start: Vector3, end: Vector3, width: float, material: Material) -> void:
	var midpoint: Vector3 = (start + end) * 0.5
	midpoint.y = 0.028
	var line := _box("Court marking", Vector3(width, 0.008, start.distance_to(end)), midpoint, material)
	line.rotation.y = atan2(end.x - start.x, end.z - start.z)

func _floor_arc(center: Vector3, radius: float, start_angle: float, end_angle: float, material: Material, dashed: bool = false) -> void:
	var segments: int = maxi(20, int(absf(end_angle - start_angle) * radius * 9.0))
	for index in range(segments):
		if dashed and index % 6 >= 3:
			continue
		var a: float = lerpf(start_angle, end_angle, float(index) / float(segments))
		var b: float = lerpf(start_angle, end_angle, float(index + 1) / float(segments))
		var point_a: Vector3 = center + Vector3(sin(a), 0, cos(a)) * radius
		var point_b: Vector3 = center + Vector3(sin(b), 0, cos(b)) * radius
		_floor_line(point_a, point_b, 0.045, material)

func _floor_brand(center: Vector3, text: String, pixel_size: float, color: Color) -> void:
	var label := Label3D.new()
	label.text = text
	label.font_size = 96
	label.pixel_size = pixel_size
	label.modulate = color
	label.outline_size = 0
	label.rotation_degrees.x = -90
	label.position = center
	add_child(label)

func _add_arena_detail(length: float) -> void:
	var metal: Material = _material("dark metal",Color("24303e"),0.4)
	var concrete: Material = _material("concrete",Color("202c3c"))
	var white: Material = _material("warm white",Color("b8b5ab"))
	var led: Material = _material("light panels",Color("c2e6ed"),0.4,true)
	var generator := RandomNumberGenerator.new()
	generator.seed = 18292
	var crowd_colors: Array[Color] = [Color("355f65"),Color("a0603c"),Color("5a465e"),Color("d2c7a0"),Color("34465f"),Color("753e3b")]
	var skin_colors: Array[Color] = [Color("855136"),Color("bc8862"),Color("5a3828"),Color("d5ab85")]
	for side: float in [-1.0,1.0]:
		# Seated silhouettes are layered into the tiers, with varied clothes and heads.
		for row in range(4):
			for index in range(int(length/0.92)):
				if generator.randf()<0.14 or index%8==0:
					continue
				var x: float = side*(10.2+row*0.85)
				var y: float = 0.35+row*0.44
				var z: float = -length*0.5+index*0.92
				var cloth: Material = _material("fan shirt %d"%(index%6),crowd_colors[index%6])
				var skin: Material = _material("fan skin %d"%(row%4),skin_colors[row%4])
				_detail_sphere(Vector3(x,y+0.65,z),Vector3(0.32,0.50,0.39),cloth)
				_detail_sphere(Vector3(x,y+1.02,z),Vector3(0.22,0.26,0.23),skin)
				for arm_side: float in [-1.0,1.0]:
					var raised: float = 0.45 if index%7==0 else -0.18
					_beam(Vector3(x,y+0.81,z+arm_side*0.22),Vector3(x-side*0.22,y+0.81+raised,z+arm_side*0.3),0.055,cloth)
					_beam(Vector3(x,y+0.31,z+arm_side*0.12),Vector3(x-side*0.29,y+0.12,z+arm_side*0.12),0.065,metal)
		# Tunnel openings and concourse structures add depth behind the seating.
		for z: float in [-length*0.35,length*0.35]:
			_box("Tunnel shadow",Vector3(0.18,2.8,1.7),Vector3(side*13.5,1.4,z),_material("tunnel",Color("080f18")))
			for dz: float in [-1.0,1.0]:
				_box("Tunnel pillar",Vector3(0.5,3.3,0.28),Vector3(side*13.3,1.65,z+dz),concrete)
			_box("Exit strip",Vector3(0.2,0.12,0.7),Vector3(side*13.1,2.7,z),_material("exit",Color("3faf95"),0.5,true))
		for z: float in [-length*0.4,0.0,length*0.4]:
			_beam(Vector3(side*12.9,4.4,z-1.8),Vector3(side*12.9,4.4,z+1.8),0.05,metal)
			_box("Suspended light",Vector3(0.55,0.07,1.25),Vector3(side*12.9,4.3,z),led)
			_box("Banner panel",Vector3(0.07,1.3,1.5),Vector3(side*13.6,3.3,z),_material("banner",Color("234951")))
	# Courtside benches and scorer's table sit behind the end line.
	var end_z: float = length*0.5+2.2
	for x: float in [-5.2,5.2]:
		_box("Team bench",Vector3(3.0,0.12,0.55),Vector3(x,0.5,end_z),metal)
		_box("Bench back",Vector3(3.0,0.42,0.1),Vector3(x,0.78,end_z+0.22),concrete)
		for offset: float in [-1.1,1.1]:
			_beam(Vector3(x+offset,0.05,end_z),Vector3(x+offset,0.5,end_z),0.045,metal)
		for bottle in range(3):
			_beam(Vector3(x-0.5+bottle*0.4,0.58,end_z),Vector3(x-0.5+bottle*0.4,0.82,end_z),0.045,_material("bottles",Color("5bafbd")))
	_box("Scorer desk",Vector3(3.0,0.9,0.75),Vector3(0,0.45,end_z),concrete)
	_box("Desk top",Vector3(3.1,0.07,0.83),Vector3(0,0.92,end_z),white)
	for x: float in [-0.85,0.85]:
		_box("Monitor",Vector3(0.55,0.36,0.05),Vector3(x,1.15,end_z),metal)
		_box("Monitor screen",Vector3(0.48,0.28,0.01),Vector3(x,1.15,end_z-0.035),_material("screen",Color("266374"),0.5,true))
	for x: float in [-8.5,8.5]:
		var center := Vector3(x,1.5,-length*0.5-1.0)
		for angle: float in [0.0,TAU/3.0,TAU*2.0/3.0]:
			_beam(center,Vector3(x+cos(angle)*0.4,0.05,center.z+sin(angle)*0.4),0.025,metal)
		_box("Broadcast camera",Vector3(0.28,0.25,0.5),center+Vector3.UP*0.08,metal)
		_detail_sphere(center+Vector3(0,0.08,0.28),Vector3(0.17,0.17,0.08),_material("lens",Color("183b4c"),0.15))

func _detail_sphere(center: Vector3, size: Vector3, material: Material) -> void:
	var instance := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = 0.5
	mesh.height = 1.0
	mesh.radial_segments = 10
	mesh.rings = 5
	instance.mesh = mesh
	instance.material_override = material
	instance.position = center
	instance.scale = size
	add_child(instance)
