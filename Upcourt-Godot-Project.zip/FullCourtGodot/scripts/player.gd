extends Node3D
## One shared movement model for human and computer players.

var team: int = 0
var slot: int = 0
var roster_index: int = 0
var data: Dictionary = {}
var velocity: Vector3 = Vector3.ZERO
var stamina: float = 100.0
var jump_timer: float = 0.0
var jump_height: float = 0.0
var action_cooldown: float = 0.0
var crossover_timer: float = 0.0
var crossover_cooldown: float = 0.0
var decision_timer: float = 0.0
var charge: float = -1.0
var desired_release: float = 0.72
var layup: bool = false
var hand: float = 1.0
var visual: Node3D
var has_ball: bool = false
var selected: bool = false
var dribble_timer: float = 0.0
var move_kind: String = "cross"
var move_duration: float = 0.45
var move_from_hand: float = 1.0
var follow_through: float = 0.0
var pass_pose: float = 0.0
var defending: bool = false

func setup(player_data: Dictionary, team_index: int, team_slot: int, color: Color, trim: Color) -> void:
	data = player_data.duplicate(true)
	team = team_index
	slot = team_slot
	roster_index = team_slot
	name = "Player_%d_%d" % [team, slot]
	visual = load("res://scripts/player_visual.gd").new()
	add_child(visual)
	visual.build(data, color, trim)

func rating(key: String) -> float:
	return clampf(float(data.get("ratings", {}).get(key, 65.0)), 25.0, 99.0)

func tick(direction: Vector3, sprint: bool, delta: float) -> void:
	follow_through = maxf(0.0,follow_through-delta)
	pass_pose = maxf(0.0,pass_pose-delta)
	action_cooldown = maxf(0.0, action_cooldown - delta)
	crossover_cooldown = maxf(0.0, crossover_cooldown - delta)
	crossover_timer = maxf(0.0, crossover_timer - delta)
	decision_timer = maxf(0.0, decision_timer - delta)
	jump_timer = maxf(0.0, jump_timer - delta)
	jump_height = sin((1.0 - jump_timer / 0.72) * PI) * 0.72 if jump_timer > 0.0 else 0.0
	var moving: bool = direction.length_squared() > 0.01
	var running: bool = sprint and moving and stamina > 3.0 and charge < 0.0
	stamina = clampf(stamina + (-20.0 if running else 12.0) * delta, 0.0, 100.0)
	var speed: float = lerpf(4.1, 6.5, (rating("speed") - 25.0) / 74.0)
	if running:
		speed *= 1.34
	if has_ball:
		speed *= lerpf(0.84, 0.96, rating("handling") / 99.0)
	if charge >= 0.0:
		speed *= 0.28 if layup else 0.10
	if crossover_timer > 0.0:
		speed *= 1.14
	var target: Vector3 = direction.limit_length(1.0) * speed
	velocity = velocity.move_toward(target, 34.0 * delta)
	position += velocity * delta
	if velocity.length_squared() > 0.1 and charge < 0.0:
		rotation.y = lerp_angle(rotation.y, atan2(-velocity.x, -velocity.z), minf(1.0, delta * 16.0))
	visual.position.y = 0.0
	visual.set_motion_context({"hand":hand,"bounce":absf(sin(dribble_timer*7.4)),"defending":defending,"follow_through":minf(1.0,follow_through*3.0),"pass_pose":pass_pose,"move_kind":move_kind,"move_progress":1.0-crossover_timer/move_duration if crossover_timer>0.0 else -1.0})
	visual.animate(velocity.length(), has_ball, maxf(0.0, charge), jump_height, delta)
	visual.set_selected(selected)
	dribble_timer += delta * (1.0 + velocity.length() * 0.035)

func jump() -> bool:
	if jump_timer > 0.0 or action_cooldown > 0.0:
		return false
	jump_timer = 0.72
	action_cooldown = 0.85
	return true

func reset_motion() -> void:
	velocity = Vector3.ZERO
	jump_timer = 0.0
	jump_height = 0.0
	charge = -1.0
	crossover_timer = 0.0
	action_cooldown = 0.0
	crossover_cooldown = 0.0
	decision_timer = 0.0
	follow_through = 0.0
	pass_pose = 0.0
	hand = 1.0
	dribble_timer = 0.0
	has_ball = false

func begin_dribble_move(kind: String = "cross") -> bool:
	if not has_ball or charge>=0.0 or crossover_cooldown>0.0 or stamina<6.0:
		return false
	move_kind = kind
	move_from_hand = hand
	hand *= -1.0
	move_duration = lerpf(0.62,0.36,(rating("handling")-25.0)/74.0)
	crossover_timer = move_duration
	crossover_cooldown = move_duration+0.22
	stamina = maxf(0.0,stamina-6.0)
	return true

func hand_position(clock: float = 0.0) -> Vector3:
	var local: Vector3 = Vector3(hand*0.43,0.22+absf(sin((clock+dribble_timer)*7.4))*0.91,-0.12)
	if crossover_timer>0.0:
		var progress: float = clampf(1.0-crossover_timer/move_duration,0.0,1.0)
		local.x = lerpf(move_from_hand*0.48,hand*0.48,smoothstep(0,1,progress))
		local.y = 0.18+0.85*absf(cos(progress*PI))
		local.z = 0.38*sin(progress*PI) if move_kind=="behind" else (-0.02 if move_kind=="between" else -0.39)
	if charge>=0.0:
		local = Vector3(0.12,1.55+jump_height,-0.32)
	return position+Basis(Vector3.UP,rotation.y)*local
