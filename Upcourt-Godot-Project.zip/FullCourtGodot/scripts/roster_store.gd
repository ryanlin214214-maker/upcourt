extends RefCounted

const DEFAULT_PATH := "res://data/rosters.json"
const LOCAL_PATH := "user://rosters.json"
const RATING_KEYS := ["speed", "shooting", "finishing", "defense", "passing", "handling", "rebounding"]

static func load_teams() -> Array:
	for path: String in [LOCAL_PATH, DEFAULT_PATH]:
		if not FileAccess.file_exists(path):
			continue
		var file := FileAccess.open(path, FileAccess.READ)
		if file == null:
			continue
		var document: Variant = JSON.parse_string(file.get_as_text())
		if not document is Dictionary:
			continue
		var teams: Variant = document.get("teams", [])
		if teams is Array and validate_teams(teams).is_empty():
			return teams
	return []

static func save_teams(teams: Array) -> Error:
	if not validate_teams(teams).is_empty():
		return ERR_INVALID_DATA
	var temporary := LOCAL_PATH + ".tmp"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		return FileAccess.get_open_error()
	file.store_string(JSON.stringify({"schema_version": 1, "teams": teams}, "\t"))
	file.flush()
	file.close()
	return DirAccess.rename_absolute(ProjectSettings.globalize_path(temporary), ProjectSettings.globalize_path(LOCAL_PATH))

static func validate_teams(teams: Array) -> String:
	if teams.size() < 2:
		return "A roster needs at least two teams."
	var team_ids: Dictionary = {}
	for team: Variant in teams:
		if not team is Dictionary:
			return "A team entry is invalid."
		for field: String in ["id", "city", "name", "abbr"]:
			if not team.get(field, "") is String or str(team.get(field, "")).strip_edges().is_empty():
				return "Every team needs an ID, city, name, and abbreviation."
		if team_ids.has(team["id"]):
			return "Team IDs must be unique."
		team_ids[team["id"]] = true
		if not Color.html_is_valid(str(team.get("color", ""))) or not Color.html_is_valid(str(team.get("trim", ""))):
			return "Team colors must be hexadecimal colors."
		if not asset_path_allowed(str(team.get("logo_path", ""))):
			return "Logos must be local files in the assets folder."
		var players: Variant = team.get("players", [])
		if not players is Array or players.size() < 6:
			return "Each team needs at least six players."
		var player_ids: Dictionary = {}
		for player: Variant in players:
			if not player is Dictionary:
				return "A player entry is invalid."
			for field: String in ["id", "name"]:
				if not player.get(field, "") is String or str(player.get(field, "")).strip_edges().is_empty():
					return "Every player needs a name and ID."
			if player_ids.has(player["id"]):
				return "Player IDs must be unique within a team."
			player_ids[player["id"]] = true
			var number: Variant = player.get("number", -1)
			if not _number(number) or float(number) != floorf(float(number)) or float(number) < 0 or float(number) > 99:
				return "Jersey numbers must be whole numbers from 0 to 99."
			var height: Variant = player.get("height", 0)
			if not _number(height) or float(height) < 1.5 or float(height) > 2.5:
				return "Player heights must be between 1.50 and 2.50 metres."
			var ratings: Variant = player.get("ratings", {})
			if not ratings is Dictionary:
				return "Player ratings are missing."
			for key: String in RATING_KEYS:
				var value: Variant = ratings.get(key, 0)
				if not _number(value) or float(value) < 25 or float(value) > 99:
					return "Ratings must be numbers from 25 to 99."
			if not asset_path_allowed(str(player.get("model_path", ""))):
				return "Player models must be local files in the assets folder."
	return ""

static func _number(value: Variant) -> bool:
	return (value is float or value is int) and is_finite(float(value))

static func asset_path_allowed(path: String) -> bool:
	return path.is_empty() or ((path.begins_with("res://assets/") or path.begins_with("user://assets/")) and not path.contains(".."))
