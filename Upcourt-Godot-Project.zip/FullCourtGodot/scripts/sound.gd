extends Node
## Small voice pool for the game's original generated effects.

const EFFECTS = {
	"bounce": preload("res://assets/audio/bounce.wav"),
	"squeak": preload("res://assets/audio/squeak.wav"),
	"rim": preload("res://assets/audio/rim.wav"),
	"make": preload("res://assets/audio/make.wav"),
	"whistle": preload("res://assets/audio/whistle.wav"),
	"pass": preload("res://assets/audio/pass.wav"),
}
const BASE_LEVELS = {
	"bounce": -10.0, "squeak": -13.0, "rim": -7.0,
	"make": -5.0, "whistle": -10.0, "pass": -7.0,
}
var _voices: Array[AudioStreamPlayer] = []
var _next_voice: int = 0
var _muted: bool = false


func _ready() -> void:
	for index in range(10):
		var voice := AudioStreamPlayer.new()
		voice.name = "EffectVoice%d" % index
		add_child(voice)
		_voices.append(voice)


func play(effect: String, volume_db: float = 0.0) -> void:
	if _muted or DisplayServer.get_name() == "headless" or not EFFECTS.has(effect) or _voices.is_empty():
		return
	var voice: AudioStreamPlayer = _voices[_next_voice]
	_next_voice = (_next_voice + 1) % _voices.size()
	voice.stop()
	voice.stream = EFFECTS[effect]
	voice.volume_db = float(BASE_LEVELS[effect]) + volume_db
	voice.pitch_scale = randf_range(0.96, 1.04) if effect != "make" else 1.0
	voice.play()


func set_muted(value: bool) -> void:
	_muted = value
	if _muted:
		for voice in _voices:
			voice.stop()
