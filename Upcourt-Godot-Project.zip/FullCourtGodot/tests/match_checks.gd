extends SceneTree
## Run with Godot --headless --path <project> --script res://tests/match_checks.gd.
## Fixtures exercise the production simulation and normal action methods.

const STEP: float = 1.0 / 60.0
var game
var failures: Array[String] = []
var passed: int = 0


func _initialize() -> void:
	call_deferred("run_checks")


func check(condition: bool, label: String) -> void:
	if condition:
		passed += 1
		print("PASS " + label)
	else:
		failures.append(label)
		push_error("FAIL " + label)


func configuration(mode: String = "half") -> Dictionary:
	return {"home_index": 0, "away_index": 1, "mode": mode,
		"difficulty": 1, "quarter_seconds": 60}


func reset_match(mode: String = "half") -> void:
	for action: String in ["move_left", "move_right", "move_up", "move_down", "sprint", "shoot"]:
		Input.action_release(action)
	game.autoplay = false
	game.solo_mode = false
	game.start_match(configuration(mode))
	game.rng.seed = 78219
	for index in range(90):
		game.step(STEP)


func advance(seconds: float) -> void:
	for index in range(int(ceil(seconds / STEP))):
		game.step(STEP)


func move_other_players_far(point: Vector3) -> void:
	var index: int = 0
	for player in game.players:
		if player == game.ball_owner:
			continue
		player.reset_motion()
		player.position = point + Vector3(float(index % 3) * 0.9, 0, float(index / 3) * 0.9)
		index += 1


func run_checks() -> void:
	var scene: PackedScene = load("res://scenes/main.tscn")
	if scene == null:
		push_error("Main scene did not load")
		quit(1)
		return
	game = scene.instantiate()
	root.add_child(game)
	game.set_physics_process(false)
	await process_frame
	game.test_mode = true
	var document: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/rosters.json"))
	game.teams = document.teams
	check(game.phase == "menu", "main scene opens to Play Now")
	test_movement()
	test_shot_model()
	test_pass()
	test_scoring()
	test_block_and_rebound()
	test_clear_and_restart()
	test_rematch()
	test_full_court_rules()
	test_pause_and_substitution()
	await process_frame
	test_complete_match("half")
	await process_frame
	test_complete_match("full")
	await process_frame
	game.queue_free()
	await process_frame
	print("RESULT %d passed, %d failed" % [passed, failures.size()])
	for failure: String in failures:
		print("FAILED " + failure)
	quit(0 if failures.is_empty() else 1)


func test_movement() -> void:
	reset_match()
	var player = game.active
	player.position = Vector3(-3, 0, 4)
	move_other_players_far(Vector3(-5, 0, -4))
	var initial: Vector3 = player.position
	Input.action_press("move_right")
	advance(0.35)
	Input.action_release("move_right")
	var walk_distance: float = player.position.x - initial.x
	check(walk_distance > 0.8, "keyboard action moves controlled player responsively")
	player.reset_motion()
	player.has_ball = true
	player.position = initial
	player.stamina = 100.0
	Input.action_press("move_right")
	Input.action_press("sprint")
	advance(0.35)
	Input.action_release("move_right")
	Input.action_release("sprint")
	check(player.position.x - initial.x > walk_distance * 1.12, "sprint increases movement speed")
	check(player.stamina < 100.0, "sprint consumes stamina")
	check(game.ball_position.distance_to(player.position) < 2.0, "dribble stays attached to ball handler")
	var controller_bound: bool = false
	for event: InputEvent in InputMap.action_get_events("shoot"):
		if event is InputEventJoypadButton:
			controller_bound = event.button_index == JOY_BUTTON_X
	check(controller_bound, "controller shot action is bound")


func test_shot_model() -> void:
	var ideal: Dictionary = game.evaluate_shot(85.0, 0.72, 5.5, 0.0, false)
	var early: Dictionary = game.evaluate_shot(85.0, 0.15, 5.5, 0.0, false)
	var contested: Dictionary = game.evaluate_shot(85.0, 0.72, 5.5, 0.95, false)
	var distant: Dictionary = game.evaluate_shot(85.0, 0.72, 11.0, 0.0, false)
	var weak: Dictionary = game.evaluate_shot(35.0, 0.60, 6.0, 0.15, false)
	var strong: Dictionary = game.evaluate_shot(95.0, 0.60, 6.0, 0.15, false)
	check(float(ideal.chance) > float(early.chance), "release timing changes shot probability")
	check(float(ideal.chance) > float(contested.chance), "defensive contest lowers shot probability")
	check(float(ideal.chance) > float(distant.chance), "deep distance lowers shot probability")
	check(float(strong.chance) > float(weak.chance), "shooting rating changes shot probability")
	var layup: Dictionary = game.evaluate_shot(85.0, 0.72, 1.4, 0.0, true)
	check(float(layup.chance) > 0.60, "close layup uses finishing model")


func test_pass() -> void:
	reset_match()
	var passer = game.ball_owner
	var target = game.team_players(0)[1]
	passer.position = Vector3(0, 0, 3.0)
	target.position = Vector3(-3, 0, 2.0)
	for defender in game.team_players(1):
		defender.position = Vector3(5.0 + float(defender.slot) * 0.7, 0, -5.0)
	game.pass_ball(passer, target)
	check(game.ball_state == "pass", "pass starts a ball flight")
	var intended: int = game.last_pass_target
	for index in range(150):
		game.step(STEP)
		if game.last_catch_target == intended:
			break
	check(game.last_pass_target == intended and game.last_catch_target == intended,
		"uncontested pass reaches the intended teammate")
	check(game.ball_owner == target, "pass transfers possession to receiver")


func test_scoring() -> void:
	reset_match()
	var player = game.ball_owner
	player.position = Vector3(0, 0, -3.6)
	player.data.ratings.finishing = 99
	move_other_players_far(Vector3(4.5, 0, 4.0))
	game.start_shot(player)
	check(player.charge >= 0.0 and player.layup, "close shot selects layup animation and timing")
	player.charge = 0.72
	game.release_shot(player)
	# Fix the make outcome for this accounting fixture; probability is tested above.
	game.planned_make = true
	check(game.attempts[0] == 1 and game.ball_state == "shot", "release records one attempt and launches ball")
	for index in range(180):
		game.step(STEP)
		if game.scores[0] > 0:
			break
	check(game.scores[0] == 1, "inside-arc make counts one pickup point")
	var score: int = game.scores[0]
	advance(0.35)
	check(game.scores[0] == score and game.makes[0] == 1, "basket counts exactly once")
	check(game.possession_team == 1, "made basket restarts with opposing team")


func test_block_and_rebound() -> void:
	reset_match()
	var shooter = game.ball_owner
	shooter.position = Vector3(0, 0, -3.5)
	game.start_shot(shooter)
	shooter.charge = 0.72
	game.release_shot(shooter)
	var defender = game.team_players(1)[0]
	defender.position = Vector3(0, 0, -3.5)
	defender.jump_timer = 0.4
	defender.jump_height = 0.5
	game.ball_position = defender.position + Vector3.UP * 2.6
	check(game.check_block(), "jumping defender can block a reachable shot")
	check(game.ball_state == "loose" and game.blocks[1] == 1, "block creates a live loose ball")
	for player in game.players:
		if player != defender:
			player.position = Vector3(5, 0, 4)
	game.ball_position = defender.position + Vector3.UP * 0.6
	game.rebound_delay = 0.0
	game.try_rebound()
	check(game.ball_owner == defender and game.rebounds[1] == 1,
		"nearby defender secures the loose rebound")
	check(game.needs_clear, "defensive rebound requires clearing before a shot")


func test_clear_and_restart() -> void:
	reset_match()
	var defender = game.team_players(1)[0]
	defender.position = Vector3(0, 0, -3)
	game.take_possession(defender, true)
	check(game.needs_clear, "defensive possession requires clearing the arc")
	var before: int = game.attempts[1]
	game.start_shot(defender)
	check(defender.charge < 0 and game.attempts[1] == before, "uncleared possession cannot shoot")
	defender.position = Vector3(0, 0, 3)
	game.check_clear()
	check(not game.needs_clear, "ball clears when handler crosses the arc")
	game.start_shot(defender)
	check(defender.charge >= 0, "cleared handler can start a shot")
	reset_match()
	game.ball_owner.position.x = 8.0
	game.check_out_of_bounds()
	check(game.phase == "restart" and game.possession_team == 1,
		"out-of-bounds restarts opposing possession")


func test_rematch() -> void:
	game.scores.assign([11, 7])
	game.attempts.assign([14, 10])
	game.steals.assign([3, 2])
	game.needs_clear = true
	game.rematch()
	check(game.scores == [0, 0] and game.attempts == [0, 0] and game.steals == [0, 0],
		"rematch resets score and statistics")
	check(game.quarter == 1 and not game.needs_clear and game.ball_owner != null,
		"rematch resets quarter, clearance, and possession")
	check(game.players.size() == 6, "rematch rebuilds exactly six pickup players")


func test_full_court_rules() -> void:
	reset_match("full")
	check(game.players.size() == 10 and game.full_court, "full-court mode starts five players per team")
	check(game.shot_clock > 20.0, "full-court starts a 24-second possession")
	check(game.last_pass_target >= 0, "full-court restart inbounds to a teammate")
	game.shot_clock = 0.01
	game.ball_state = "held"
	var old_team: int = game.possession_team
	game.step(STEP)
	check(game.phase == "restart" and game.possession_team != old_team,
		"shot-clock expiry changes possession")
	game.phase = "live"
	game.game_clock = 0.0
	game.ball_state = "held"
	game.finish_period()
	check(game.phase == "break", "quarter expiry opens period break")
	game.resume_game()
	check(game.quarter == 2 and game.game_clock > 0.0, "next period resets game clock")


func test_complete_match(mode: String) -> void:
	reset_match(mode)
	game.autoplay = true
	game.rng.seed = 12051 if mode == "half" else 27182
	var steps: int = 0
	var maximum_steps: int = 90000
	while game.phase != "final" and steps < maximum_steps:
		if game.phase == "break":
			game.resume_game()
		game.step(STEP)
		steps += 1
	check(game.phase == "final", "%s autoplay completes a full match" % mode)
	if mode == "half":
		check(maxi(game.scores[0], game.scores[1]) >= 11, "pickup ends at target score")
	else:
		check(game.quarter >= 4 and game.scores[0] != game.scores[1],
			"full-court completes four quarters and resolves ties")
	print("MATCH %s score=%s simulated_seconds=%.2f events=%d" % [
		mode, str(game.scores), float(steps) * STEP, game.match_events.size()])


func test_pause_and_substitution() -> void:
	reset_match("full")
	game.pause_game()
	var clock_before: float = game.game_clock
	advance(1.0)
	check(game.phase == "paused" and game.game_clock == clock_before, "pause freezes the game clock")
	var bench: Array = game.bench_players()
	var replacement_index: int = bench[0].slot
	game.substitute(replacement_index)
	check(game.active.roster_index == replacement_index and game.players.size() == 10, "substitution replaces one player and preserves five per team")
	game.resume_game()
	check(game.phase == "live", "resume returns to live play")
	var event := InputEventJoypadButton.new()
	event.button_index = JOY_BUTTON_X
	event.pressed = true
	game.take_possession(game.active)
	game._input(event)
	check(game.active.charge >= 0.0, "controller X begins a shot through the input handler")
	event.pressed = false
	game._input(event)
	check(game.ball_state == "shot", "controller X release launches the ball")
